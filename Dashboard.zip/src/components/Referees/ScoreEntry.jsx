import React, { useState, useEffect } from 'react';
import { updateLeagueTable } from '../../utils/dataManager';

const ScoreEntry = () => {
  const [matches, setMatches] = useState([]);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [homeScore, setHomeScore] = useState('');
  const [awayScore, setAwayScore] = useState('');
  const [filterDivision, setFilterDivision] = useState('');

  useEffect(() => {
    loadMatches();
  }, []);

  const loadMatches = () => {
    const matchesData = JSON.parse(localStorage.getItem('matches') || '[]');
    setMatches(matchesData);
  };

  const handleScoreSubmit = (e) => {
    e.preventDefault();
    
    if (homeScore === '' || awayScore === '') {
      alert('Please enter both home and away scores');
      return;
    }

    const homeScoreNum = parseInt(homeScore);
    const awayScoreNum = parseInt(awayScore);

    if (homeScoreNum < 0 || awayScoreNum < 0) {
      alert('Scores cannot be negative');
      return;
    }

    // Update match
    const matchesData = JSON.parse(localStorage.getItem('matches') || '[]');
    const updatedMatches = matchesData.map(match => 
      match.id === selectedMatch.id 
        ? { ...match, homeScore: homeScoreNum, awayScore: awayScoreNum, status: 'completed' }
        : match
    );
    
    localStorage.setItem('matches', JSON.stringify(updatedMatches));
    
    // Update league table
    updateLeagueTable(selectedMatch.homeTeam, selectedMatch.awayTeam, homeScoreNum, awayScoreNum);
    
    // Reset form
    setMatches(updatedMatches);
    setSelectedMatch(null);
    setHomeScore('');
    setAwayScore('');
    
    alert('Score updated successfully!');
  };

  const scheduledMatches = matches.filter(match => {
    const isScheduled = match.status === 'scheduled';
    const matchesDivision = !filterDivision || match.division.toString() === filterDivision;
    return isScheduled && matchesDivision;
  });

  const completedMatches = matches.filter(match => {
    const isCompleted = match.status === 'completed';
    const matchesDivision = !filterDivision || match.division.toString() === filterDivision;
    return isCompleted && matchesDivision;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Score Entry</h2>
        <div className="flex items-center space-x-4">
          <select
            value={filterDivision}
            onChange={(e) => setFilterDivision(e.target.value)}
            className="border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value="">All Divisions</option>
            <option value="1">Division 1</option>
            <option value="2">Division 2</option>
          </select>
        </div>
      </div>

      {/* Score Entry Form */}
      {selectedMatch && (
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Enter Match Score</h3>
          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            <div className="text-center">
              <h4 className="text-xl font-semibold text-gray-900">
                {selectedMatch.homeTeam} vs {selectedMatch.awayTeam}
              </h4>
              <p className="text-gray-600">
                {selectedMatch.date} at {selectedMatch.time} - {selectedMatch.venue}
              </p>
              <p className="text-sm text-gray-500">Division {selectedMatch.division}</p>
            </div>
          </div>
          
          <form onSubmit={handleScoreSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {selectedMatch.homeTeam} Score
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={homeScore}
                  onChange={(e) => setHomeScore(e.target.value)}
                  className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {selectedMatch.awayTeam} Score
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={awayScore}
                  onChange={(e) => setAwayScore(e.target.value)}
                  className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="0"
                />
              </div>
            </div>
            
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => {
                  setSelectedMatch(null);
                  setHomeScore('');
                  setAwayScore('');
                }}
                className="bg-gray-300 hover:bg-gray-400 text-black px-4 py-2 rounded-md text-sm font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium"
              >
                Submit Score
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Scheduled Matches */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Scheduled Matches</h3>
          <p className="text-sm text-gray-500">Click on a match to enter the score</p>
        </div>
        <div className="divide-y divide-gray-200">
          {scheduledMatches.length === 0 ? (
            <div className="px-6 py-8 text-center text-gray-500">
              No scheduled matches found
            </div>
          ) : (
            scheduledMatches.map((match) => (
              <div
                key={match.id}
                onClick={() => setSelectedMatch(match)}
                className="px-6 py-4 hover:bg-gray-50 cursor-pointer transition-colors"
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {match.homeTeam} vs {match.awayTeam}
                    </h4>
                    <p className="text-sm text-gray-500">
                      {match.date} at {match.time} - {match.venue}
                    </p>
                    <p className="text-xs text-gray-400">Division {match.division}</p>
                  </div>
                  <div className="text-indigo-600 hover:text-indigo-900">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Completed Matches */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Recent Completed Matches</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {completedMatches.slice(0, 10).map((match) => (
            <div key={match.id} className="px-6 py-4">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="font-medium text-gray-900">
                    {match.homeTeam} vs {match.awayTeam}
                  </h4>
                  <p className="text-sm text-gray-500">
                    {match.date} at {match.time} - {match.venue}
                  </p>
                  <p className="text-xs text-gray-400">Division {match.division}</p>
                </div>
                <div className="text-right">
                  <div className="text-lg font-semibold text-gray-900">
                    {match.homeScore} - {match.awayScore}
                  </div>
                  <div className="text-sm text-green-600">Completed</div>
                </div>
              </div>
            </div>
          ))}
          {completedMatches.length === 0 && (
            <div className="px-6 py-8 text-center text-gray-500">
              No completed matches found
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ScoreEntry;