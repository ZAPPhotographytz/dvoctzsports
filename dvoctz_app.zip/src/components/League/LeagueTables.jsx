import React, { useState, useEffect } from 'react';
import { leagueManager, matchesManager } from '../../utils/dataManager';
import LineChartComponent from '../charts/LineChart';
import PieChartComponent from '../charts/PieChart';
import BarChartComponent from '../charts/BarChart';

const LeagueTables = () => {
  const [standings, setStandings] = useState([]);
  const [leagueSettings, setLeagueSettings] = useState(null);
  const [recentMatches, setRecentMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Fetch league standings
      const { standings: standingsData, error: standingsError } = await leagueManager.getStandings();
      
      if (standingsError) {
        throw new Error(standingsError.message);
      }
      
      // Fetch league settings
      const { settings: settingsData, error: settingsError } = await leagueManager.getSettings();
      
      if (settingsError) {
        throw new Error(settingsError.message);
      }
      
      // Fetch recent matches (for charts)
      const { matches: matchesData, error: matchesError } = await matchesManager.getAll();
      
      if (matchesError) {
        throw new Error(matchesError.message);
      }
      
      // Get only completed matches
      const completedMatches = (matchesData || []).filter(match => match.status === 'completed');
      
      setStandings(standingsData || []);
      setLeagueSettings(settingsData);
      setRecentMatches(completedMatches);
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Failed to load data. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  // Prepare data for top scorers chart (bar chart)
  const prepareTeamPerformanceData = () => {
    if (!standings.length) return { labels: [], datasets: [] };
    
    // Get top 5 teams by points
    const topTeams = [...standings].sort((a, b) => b.points - a.points).slice(0, 5);
    
    return {
      labels: topTeams.map(team => team.name),
      datasets: [
        {
          label: 'Wins',
          data: topTeams.map(team => team.wins || 0),
          backgroundColor: 'rgba(34, 197, 94, 0.7)', // Green
        },
        {
          label: 'Draws',
          data: topTeams.map(team => team.draws || 0),
          backgroundColor: 'rgba(234, 179, 8, 0.7)', // Yellow
        },
        {
          label: 'Losses',
          data: topTeams.map(team => team.losses || 0),
          backgroundColor: 'rgba(239, 68, 68, 0.7)', // Red
        },
      ]
    };
  };

  // Prepare data for goals distribution (pie chart)
  const prepareGoalsDistributionData = () => {
    if (!standings.length) return { labels: [], datasets: [] };
    
    // Get top 5 teams by goals scored
    const topTeams = [...standings].sort((a, b) => (b.goals_for || 0) - (a.goals_for || 0)).slice(0, 5);
    
    return {
      labels: topTeams.map(team => team.name),
      datasets: [
        {
          data: topTeams.map(team => team.goals_for || 0),
          backgroundColor: [
            'rgba(34, 197, 94, 0.7)',   // Green
            'rgba(59, 130, 246, 0.7)',  // Blue
            'rgba(239, 68, 68, 0.7)',   // Red
            'rgba(234, 179, 8, 0.7)',   // Yellow
            'rgba(168, 85, 247, 0.7)',  // Purple
          ],
        }
      ]
    };
  };

  // Prepare data for points trend (line chart)
  const preparePointsTrendData = () => {
    if (!standings.length) return { labels: [], datasets: [] };
    
    // Get top 5 teams by points
    const topTeams = [...standings].sort((a, b) => b.points - a.points).slice(0, 5);
    
    return {
      labels: topTeams.map(team => team.name),
      datasets: [
        {
          label: 'Points',
          data: topTeams.map(team => team.points || 0),
          borderColor: 'rgba(59, 130, 246, 0.7)',
          backgroundColor: 'rgba(59, 130, 246, 0.3)',
          fill: true,
        }
      ]
    };
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">League Tables</h1>
        {leagueSettings && (
          <p className="text-gray-600">
            {leagueSettings.name} - {leagueSettings.season}
          </p>
        )}
      </div>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-md mb-6">
          {error}
        </div>
      )}
      
      {/* League Standings Table */}
      <div className="bg-white shadow-sm rounded-lg overflow-hidden mb-8">
        <h2 className="text-lg font-medium p-4 bg-gray-50 border-b">League Standings</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pos
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Team
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  MP
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  W
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  D
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  L
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  GF
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  GA
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  GD
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pts
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {standings.length === 0 ? (
                <tr>
                  <td colSpan="10" className="px-6 py-4 text-center text-gray-500">
                    No standings data available. Matches need to be completed to generate standings.
                  </td>
                </tr>
              ) : (
                standings.map((team, index) => (
                  <tr key={team.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {index + 1}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {team.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                      {team.played || 0}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                      {team.wins || 0}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                      {team.draws || 0}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                      {team.losses || 0}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                      {team.goals_for || 0}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                      {team.goals_against || 0}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                      {team.goal_difference || 0}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-blue-600 text-center">
                      {team.points || 0}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Statistics Charts Section */}
      {standings.length > 0 && (
        <div className="mb-8">
          <h2 className="text-lg font-medium mb-4">League Statistics</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-md font-medium text-gray-800 mb-4">Team Performance</h3>
              <BarChartComponent data={prepareTeamPerformanceData()} />
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-md font-medium text-gray-800 mb-4">Points Distribution</h3>
              <LineChartComponent data={preparePointsTrendData()} />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-md font-medium text-gray-800 mb-4">Goals Distribution</h3>
              <PieChartComponent data={prepareGoalsDistributionData()} />
            </div>
            
            {/* Recent Results */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-md font-medium text-gray-800 mb-4">Recent Results</h3>
              {recentMatches.length === 0 ? (
                <p className="text-gray-500">No completed matches yet.</p>
              ) : (
                <ul className="divide-y divide-gray-200">
                  {recentMatches.slice(0, 5).map(match => (
                    <li key={match.id} className="py-3">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium text-gray-900">
                          {match.home_team?.name} vs {match.away_team?.name}
                        </span>
                        <span className="text-sm font-bold text-gray-900">
                          {match.home_score} - {match.away_score}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500">
                        {new Date(match.match_date).toLocaleDateString()}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}
      
      {/* League Information */}
      {leagueSettings && (
        <div className="bg-white shadow-sm rounded-lg overflow-hidden">
          <h2 className="text-lg font-medium p-4 bg-gray-50 border-b">League Information</h2>
          <div className="p-4">
            <dl className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-6">
              <div>
                <dt className="text-sm font-medium text-gray-500">League Name</dt>
                <dd className="mt-1 text-sm text-gray-900">{leagueSettings.name}</dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-500">Season</dt>
                <dd className="mt-1 text-sm text-gray-900">{leagueSettings.season}</dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-500">Duration</dt>
                <dd className="mt-1 text-sm text-gray-900">
                  {new Date(leagueSettings.start_date).toLocaleDateString()} to{' '}
                  {new Date(leagueSettings.end_date).toLocaleDateString()}
                </dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-500">Points System</dt>
                <dd className="mt-1 text-sm text-gray-900">
                  Win: {leagueSettings.points_for_win} pts | 
                  Draw: {leagueSettings.points_for_draw} pts | 
                  Loss: {leagueSettings.points_for_loss} pts
                </dd>
              </div>
            </dl>
          </div>
        </div>
      )}
    </div>
  );
};

export default LeagueTables;