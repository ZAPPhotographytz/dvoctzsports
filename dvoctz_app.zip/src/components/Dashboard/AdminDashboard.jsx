import React, { useState, useEffect } from 'react';
import { teamsManager, matchesManager, leagueManager } from '../../utils/dataManager';
import BarChartComponent from '../charts/BarChart';
import PieChartComponent from '../charts/PieChart';
import LineChartComponent from '../charts/LineChart';
import StatsCard from '../StatsCard';

const AdminDashboard = () => {
  const [teams, setTeams] = useState([]);
  const [matches, setMatches] = useState([]);
  const [upcomingMatches, setUpcomingMatches] = useState([]);
  const [standings, setStandings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [leagueStats, setLeagueStats] = useState({
    totalTeams: 0,
    totalMatches: 0,
    completedMatches: 0,
    upcomingMatches: 0
  });

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        // Fetch teams
        const { teams: teamsData, error: teamsError } = await teamsManager.getAll();
        if (teamsError) throw new Error(teamsError.message);
        
        // Fetch matches
        const { matches: matchesData, error: matchesError } = await matchesManager.getAll();
        if (matchesError) throw new Error(matchesError.message);
        
        // Fetch upcoming matches
        const { matches: upcomingData, error: upcomingError } = await matchesManager.getUpcoming();
        if (upcomingError) throw new Error(upcomingError.message);
        
        // Fetch standings
        const { standings: standingsData, error: standingsError } = await leagueManager.getStandings();
        if (standingsError) throw new Error(standingsError.message);
        
        setTeams(teamsData || []);
        setMatches(matchesData || []);
        setUpcomingMatches(upcomingData || []);
        setStandings(standingsData || []);
        
        // Calculate stats
        const completedMatches = (matchesData || []).filter(match => match.status === 'completed');
        
        setLeagueStats({
          totalTeams: teamsData?.length || 0,
          totalMatches: matchesData?.length || 0,
          completedMatches: completedMatches.length,
          upcomingMatches: upcomingData?.length || 0
        });
        
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);

  // Prepare stats cards data
  const statsCardsData = [
    {
      title: 'Total Teams',
      value: leagueStats.totalTeams,
      change: '+2',
      trend: 'up',
      icon: '👥'
    },
    {
      title: 'Total Matches',
      value: leagueStats.totalMatches,
      change: '+5',
      trend: 'up',
      icon: '🏆'
    },
    {
      title: 'Completed Matches',
      value: leagueStats.completedMatches,
      change: '+3',
      trend: 'up',
      icon: '✅'
    },
    {
      title: 'Upcoming Matches',
      value: leagueStats.upcomingMatches,
      change: '+2',
      trend: 'up',
      icon: '📅'
    }
  ];

  // Prepare team performance data for charts
  const prepareTeamPerformanceData = () => {
    if (!standings.length) return [];
    
    // Get top 5 teams by points
    const topTeams = [...standings].sort((a, b) => b.points - a.points).slice(0, 5);
    
    return topTeams.map(team => ({
      name: team.name,
      wins: team.wins,
      draws: team.draws,
      losses: team.losses,
      goalsFor: team.goals_for,
      goalsAgainst: team.goals_against,
      points: team.points
    }));
  };

  // Data for team performance chart (bar chart)
  const teamPerformanceData = {
    labels: prepareTeamPerformanceData().map(team => team.name),
    datasets: [
      {
        label: 'Wins',
        data: prepareTeamPerformanceData().map(team => team.wins),
        backgroundColor: 'rgba(34, 197, 94, 0.7)', // Green
      },
      {
        label: 'Draws',
        data: prepareTeamPerformanceData().map(team => team.draws),
        backgroundColor: 'rgba(234, 179, 8, 0.7)', // Yellow
      },
      {
        label: 'Losses',
        data: prepareTeamPerformanceData().map(team => team.losses),
        backgroundColor: 'rgba(239, 68, 68, 0.7)', // Red
      },
    ]
  };

  // Data for goals distribution (pie chart)
  const goalsDistributionData = {
    labels: prepareTeamPerformanceData().map(team => team.name),
    datasets: [
      {
        data: prepareTeamPerformanceData().map(team => team.goalsFor),
        backgroundColor: [
          'rgba(34, 197, 94, 0.7)',   // Green
          'rgba(59, 130, 246, 0.7)',  // Blue
          'rgba(239, 68, 68, 0.7)',   // Red
          'rgba(234, 179, 8, 0.7)',   // Yellow
          'rgba(168, 85, 247, 0.7)',  // Purple
        ],
      }
    ]
  };

  // Data for points trend (line chart)
  const pointsTrendData = {
    labels: prepareTeamPerformanceData().map(team => team.name),
    datasets: [
      {
        label: 'Points',
        data: prepareTeamPerformanceData().map(team => team.points),
        borderColor: 'rgba(59, 130, 246, 0.7)',
        backgroundColor: 'rgba(59, 130, 246, 0.3)',
        fill: true,
      }
    ]
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 text-red-600 p-4 rounded-md">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-800">League Dashboard</h1>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsCardsData.map((stat, index) => (
          <StatsCard 
            key={index}
            title={stat.title}
            value={stat.value}
            change={stat.change}
            trend={stat.trend}
            icon={stat.icon}
          />
        ))}
      </div>
      
      {/* Charts - First Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-lg font-medium text-gray-800 mb-4">Team Performance</h2>
          <BarChartComponent data={teamPerformanceData} />
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-lg font-medium text-gray-800 mb-4">Points Trend</h2>
          <LineChartComponent data={pointsTrendData} />
        </div>
      </div>
      
      {/* Charts - Second Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-lg font-medium text-gray-800 mb-4">Goals Distribution</h2>
          <PieChartComponent data={goalsDistributionData} />
        </div>
        
        {/* Upcoming Matches Panel */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-lg font-medium text-gray-800 mb-4">Upcoming Matches</h2>
          <div className="overflow-y-auto max-h-72">
            {upcomingMatches.length === 0 ? (
              <p className="text-gray-500">No upcoming matches scheduled.</p>
            ) : (
              <ul className="space-y-3">
                {upcomingMatches.slice(0, 5).map(match => (
                  <li key={match.id} className="border-b pb-2 last:border-0">
                    <div className="flex justify-between">
                      <span className="font-medium">{match.home_team.name} vs {match.away_team.name}</span>
                      <span className="text-gray-500 text-sm">
                        {new Date(match.match_date).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600">
                      {match.location || 'Location TBD'}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
      
      {/* League Standings */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-lg font-medium text-gray-800 mb-4">League Standings</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rank
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Team
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  P
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  W
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  D
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  L
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  GF
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  GA
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  GD
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  PTS
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {standings.map((team, index) => (
                <tr key={team.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {index + 1}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {team.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {team.played || 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {team.wins || 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {team.draws || 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {team.losses || 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {team.goals_for || 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {team.goals_against || 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {team.goal_difference || 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-blue-600">
                    {team.points || 0}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;