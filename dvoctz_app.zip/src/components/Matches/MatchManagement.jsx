import React, { useState, useEffect } from 'react';
import { matchesManager, teamsManager } from '../../utils/dataManager';

const MatchManagement = () => {
  const [matches, setMatches] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formMode, setFormMode] = useState('create'); // 'create' or 'edit'

  // Form state
  const [formData, setFormData] = useState({
    home_team_id: '',
    away_team_id: '',
    match_date: '',
    location: '',
    referee_id: ''
  });
  const [formError, setFormError] = useState(null);
  const [formLoading, setFormLoading] = useState(false);

  // Status filter
  const [statusFilter, setStatusFilter] = useState('all'); // 'all', 'scheduled', 'completed', etc.

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Fetch matches
      const { matches: matchesData, error: matchesError } = await matchesManager.getAll();
      
      if (matchesError) {
        throw new Error(matchesError.message);
      }
      
      // Fetch teams for dropdown
      const { teams: teamsData, error: teamsError } = await teamsManager.getAll();
      
      if (teamsError) {
        throw new Error(teamsError.message);
      }
      
      setMatches(matchesData || []);
      setTeams(teamsData || []);
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Failed to load data. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const openCreateModal = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    setFormData({
      home_team_id: teams.length > 0 ? teams[0].id : '',
      away_team_id: teams.length > 1 ? teams[1].id : '',
      match_date: tomorrow.toISOString().split('T')[0] + 'T18:00', // Default to 6 PM tomorrow
      location: '',
      referee_id: ''
    });
    setFormMode('create');
    setIsModalOpen(true);
  };

  const openEditModal = (match) => {
    const match_date = new Date(match.match_date);
    
    setFormData({
      home_team_id: match.home_team_id,
      away_team_id: match.away_team_id,
      match_date: new Date(match_date.getTime() - match_date.getTimezoneOffset() * 60000)
        .toISOString()
        .slice(0, 16), // Format as YYYY-MM-DDTHH:MM
      location: match.location || '',
      referee_id: match.referee_id || ''
    });
    setSelectedMatch(match);
    setFormMode('edit');
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setFormError(null);
    setSelectedMatch(null);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setFormError(null);
    setFormLoading(true);
    
    // Validate home and away teams are different
    if (formData.home_team_id === formData.away_team_id) {
      setFormError('Home team and away team must be different.');
      setFormLoading(false);
      return;
    }
    
    try {
      const matchData = {
        ...formData,
        match_date: new Date(formData.match_date).toISOString()
      };
      
      if (formMode === 'create') {
        const { match, error } = await matchesManager.create({
          ...matchData,
          status: 'scheduled',
          home_score: 0,
          away_score: 0
        });
        
        if (error) {
          throw new Error(error.message);
        }
        
        setMatches(prev => [...prev, match]);
      } else {
        const { match, error } = await matchesManager.update(selectedMatch.id, matchData);
        
        if (error) {
          throw new Error(error.message);
        }
        
        setMatches(prev => prev.map(m => m.id === match.id ? match : m));
      }
      
      closeModal();
      fetchData(); // Refresh to get the updated match with related data
    } catch (err) {
      console.error('Error saving match:', err);
      setFormError('Failed to save match. Please try again later.');
    } finally {
      setFormLoading(false);
    }
  };

  const handleDeleteMatch = async (matchId) => {
    if (!window.confirm('Are you sure you want to delete this match? This action cannot be undone.')) {
      return;
    }
    
    try {
      const { error } = await matchesManager.delete(matchId);
      
      if (error) {
        throw new Error(error.message);
      }
      
      setMatches(prev => prev.filter(match => match.id !== matchId));
    } catch (err) {
      console.error('Error deleting match:', err);
      alert('Failed to delete match. Please try again later.');
    }
  };

  // Filter matches based on status filter
  const filteredMatches = statusFilter === 'all' 
    ? matches 
    : matches.filter(match => match.status === statusFilter);

  // Format date for display
  const formatMatchDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get status badge color
  const getStatusBadgeClass = (status) => {
    switch(status) {
      case 'scheduled': 
        return 'bg-blue-100 text-blue-800';
      case 'in_progress': 
        return 'bg-yellow-100 text-yellow-800';
      case 'completed': 
        return 'bg-green-100 text-green-800';
      case 'cancelled': 
        return 'bg-red-100 text-red-800';
      default: 
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">Match Management</h1>
        <button 
          onClick={openCreateModal}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          Schedule New Match
        </button>
      </div>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-md mb-6">
          {error}
        </div>
      )}
      
      {/* Status filter */}
      <div className="flex space-x-2 mb-4">
        <button
          onClick={() => setStatusFilter('all')}
          className={`px-3 py-1 rounded-md text-sm font-medium ${
            statusFilter === 'all' ? 'bg-gray-200 text-gray-800' : 'bg-gray-100 text-gray-600'
          }`}
        >
          All
        </button>
        <button
          onClick={() => setStatusFilter('scheduled')}
          className={`px-3 py-1 rounded-md text-sm font-medium ${
            statusFilter === 'scheduled' ? 'bg-blue-200 text-blue-800' : 'bg-blue-100 text-blue-600'
          }`}
        >
          Scheduled
        </button>
        <button
          onClick={() => setStatusFilter('in_progress')}
          className={`px-3 py-1 rounded-md text-sm font-medium ${
            statusFilter === 'in_progress' ? 'bg-yellow-200 text-yellow-800' : 'bg-yellow-100 text-yellow-600'
          }`}
        >
          In Progress
        </button>
        <button
          onClick={() => setStatusFilter('completed')}
          className={`px-3 py-1 rounded-md text-sm font-medium ${
            statusFilter === 'completed' ? 'bg-green-200 text-green-800' : 'bg-green-100 text-green-600'
          }`}
        >
          Completed
        </button>
        <button
          onClick={() => setStatusFilter('cancelled')}
          className={`px-3 py-1 rounded-md text-sm font-medium ${
            statusFilter === 'cancelled' ? 'bg-red-200 text-red-800' : 'bg-red-100 text-red-600'
          }`}
        >
          Cancelled
        </button>
      </div>
      
      {/* Matches List */}
      <div className="bg-white shadow-sm rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Match
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date & Time
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Location
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredMatches.length === 0 ? (
              <tr>
                <td colSpan="5" className="px-6 py-4 text-center text-gray-500">
                  No matches found. Schedule a new match to get started.
                </td>
              </tr>
            ) : (
              filteredMatches.map(match => (
                <tr key={match.id}>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900">
                          {match.home_team?.name || 'Unknown'} vs {match.away_team?.name || 'Unknown'}
                        </p>
                        {match.status === 'completed' && (
                          <p className="text-sm text-gray-700 font-semibold">
                            {match.home_score} - {match.away_score}
                          </p>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatMatchDate(match.match_date)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {match.location || 'TBD'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(match.status)}`}>
                      {match.status.charAt(0).toUpperCase() + match.status.slice(1).replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => openEditModal(match)}
                      className="text-blue-600 hover:text-blue-900 mr-4"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteMatch(match.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      
      {/* Modal for Create/Edit Match */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold mb-4">
              {formMode === 'create' ? 'Schedule New Match' : 'Edit Match'}
            </h2>
            
            {formError && (
              <div className="bg-red-50 text-red-600 p-3 rounded-md text-sm mb-4">
                {formError}
              </div>
            )}
            
            <form onSubmit={handleFormSubmit}>
              <div className="mb-4">
                <label htmlFor="home_team_id" className="block text-sm font-medium text-gray-700">
                  Home Team
                </label>
                <select
                  id="home_team_id"
                  name="home_team_id"
                  value={formData.home_team_id}
                  onChange={handleFormChange}
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select home team</option>
                  {teams.map(team => (
                    <option key={`home-${team.id}`} value={team.id}>
                      {team.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="mb-4">
                <label htmlFor="away_team_id" className="block text-sm font-medium text-gray-700">
                  Away Team
                </label>
                <select
                  id="away_team_id"
                  name="away_team_id"
                  value={formData.away_team_id}
                  onChange={handleFormChange}
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select away team</option>
                  {teams.map(team => (
                    <option key={`away-${team.id}`} value={team.id}>
                      {team.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="mb-4">
                <label htmlFor="match_date" className="block text-sm font-medium text-gray-700">
                  Match Date & Time
                </label>
                <input
                  type="datetime-local"
                  id="match_date"
                  name="match_date"
                  value={formData.match_date}
                  onChange={handleFormChange}
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="location" className="block text-sm font-medium text-gray-700">
                  Location
                </label>
                <input
                  type="text"
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleFormChange}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Stadium or venue name"
                />
              </div>
              
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formLoading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                >
                  {formLoading ? 'Saving...' : formMode === 'create' ? 'Schedule Match' : 'Update Match'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default MatchManagement;