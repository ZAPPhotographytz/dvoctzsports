import React, { useState, useEffect } from 'react';
import { matchesManager, eventsManager, playersManager } from '../../utils/dataManager';
import { getCurrentUser } from '../../utils/auth';

const ScoreEntry = () => {
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [isScoreModalOpen, setIsScoreModalOpen] = useState(false);
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [scoreFormData, setScoreFormData] = useState({
    home_score: 0,
    away_score: 0
  });
  const [events, setEvents] = useState([]);
  const [players, setPlayers] = useState({
    home: [],
    away: []
  });
  const [eventFormData, setEventFormData] = useState({
    match_id: '',
    player_id: '',
    team_id: '',
    event_type: 'goal',
    event_time: '',
    description: ''
  });

  useEffect(() => {
    fetchUserMatches();
  }, []);

  const fetchUserMatches = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Get current user
      const { user } = await getCurrentUser();
      
      if (!user) {
        throw new Error('User not authenticated');
      }
      
      // Fetch matches assigned to the referee
      const { matches: matchesData, error: matchesError } = await matchesManager.getByReferee(user.id);
      
      if (matchesError) {
        throw new Error(matchesError.message);
      }
      
      setMatches(matchesData || []);
    } catch (err) {
      console.error('Error fetching matches:', err);
      setError('Failed to load matches. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const openScoreModal = (match) => {
    setSelectedMatch(match);
    setScoreFormData({
      home_score: match.home_score || 0,
      away_score: match.away_score || 0
    });
    setIsScoreModalOpen(true);
    
    // Load existing events for this match
    fetchMatchEvents(match.id);
    
    // Load players for both teams
    fetchTeamPlayers(match.home_team_id, match.away_team_id);
  };

  const fetchMatchEvents = async (matchId) => {
    try {
      const { events: eventsData, error } = await eventsManager.getByMatch(matchId);
      
      if (error) {
        console.error('Error fetching events:', error);
        return;
      }
      
      setEvents(eventsData || []);
    } catch (err) {
      console.error('Error fetching match events:', err);
    }
  };

  const fetchTeamPlayers = async (homeTeamId, awayTeamId) => {
    try {
      // Fetch home team players
      const { players: homePlayers, error: homeError } = await playersManager.getByTeam(homeTeamId);
      
      if (homeError) {
        console.error('Error fetching home team players:', homeError);
      }
      
      // Fetch away team players
      const { players: awayPlayers, error: awayError } = await playersManager.getByTeam(awayTeamId);
      
      if (awayError) {
        console.error('Error fetching away team players:', awayError);
      }
      
      setPlayers({
        home: homePlayers || [],
        away: awayPlayers || []
      });
    } catch (err) {
      console.error('Error fetching team players:', err);
    }
  };

  const closeScoreModal = () => {
    setIsScoreModalOpen(false);
    setSelectedMatch(null);
    setEvents([]);
    setPlayers({ home: [], away: [] });
  };

  const openEventModal = () => {
    setEventFormData({
      match_id: selectedMatch.id,
      player_id: '',
      team_id: '',
      event_type: 'goal',
      event_time: '',
      description: ''
    });
    setIsEventModalOpen(true);
  };

  const closeEventModal = () => {
    setIsEventModalOpen(false);
  };

  const handleScoreChange = (e) => {
    const { name, value } = e.target;
    setScoreFormData(prev => ({
      ...prev,
      [name]: parseInt(value, 10) || 0
    }));
  };

  const handleScoreSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const { match, error } = await matchesManager.updateScore(
        selectedMatch.id, 
        scoreFormData.home_score, 
        scoreFormData.away_score
      );
      
      if (error) {
        throw new Error(error.message);
      }
      
      // Update matches list
      setMatches(prev => prev.map(m => m.id === match.id ? match : m));
      alert('Match score updated successfully!');
      
      // Close the modal
      closeScoreModal();
    } catch (err) {
      console.error('Error updating score:', err);
      alert('Failed to update score. Please try again later.');
    }
  };

  const handleEventFormChange = (e) => {
    const { name, value } = e.target;
    
    // If team is selected, reset player selection
    if (name === 'team_id') {
      setEventFormData(prev => ({
        ...prev,
        [name]: value,
        player_id: ''
      }));
    } else {
      setEventFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const handleEventSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const { event, error } = await eventsManager.create(eventFormData);
      
      if (error) {
        throw new Error(error.message);
      }
      
      // Add new event to list
      setEvents(prev => [...prev, event]);
      
      // Close modal and reset form
      closeEventModal();
      
      // Refresh events
      fetchMatchEvents(selectedMatch.id);
    } catch (err) {
      console.error('Error creating event:', err);
      alert('Failed to record event. Please try again later.');
    }
  };

  const handleDeleteEvent = async (eventId) => {
    if (!window.confirm('Are you sure you want to delete this event?')) {
      return;
    }
    
    try {
      const { error } = await eventsManager.delete(eventId);
      
      if (error) {
        throw new Error(error.message);
      }
      
      // Remove event from list
      setEvents(prev => prev.filter(event => event.id !== eventId));
    } catch (err) {
      console.error('Error deleting event:', err);
      alert('Failed to delete event. Please try again later.');
    }
  };

  // Format date for display
  const formatMatchDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get status badge color
  const getStatusBadgeClass = (status) => {
    switch(status) {
      case 'scheduled': 
        return 'bg-blue-100 text-blue-800';
      case 'in_progress': 
        return 'bg-yellow-100 text-yellow-800';
      case 'completed': 
        return 'bg-green-100 text-green-800';
      case 'cancelled': 
        return 'bg-red-100 text-red-800';
      default: 
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Get event type badge color
  const getEventTypeBadgeClass = (type) => {
    switch(type) {
      case 'goal': 
        return 'bg-green-100 text-green-800';
      case 'yellow_card': 
        return 'bg-yellow-100 text-yellow-800';
      case 'red_card': 
        return 'bg-red-100 text-red-800';
      case 'substitution': 
        return 'bg-blue-100 text-blue-800';
      case 'injury': 
        return 'bg-orange-100 text-orange-800';
      case 'penalty': 
        return 'bg-purple-100 text-purple-800';
      default: 
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">Referee Score Entry</h1>
        <p className="text-gray-600">Manage scores and match events for your assigned matches.</p>
      </div>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-md mb-6">
          {error}
        </div>
      )}
      
      {/* Matches List */}
      <div className="bg-white shadow-sm rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Match
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date & Time
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Location
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Score
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {matches.length === 0 ? (
              <tr>
                <td colSpan="6" className="px-6 py-4 text-center text-gray-500">
                  No matches assigned to you as a referee.
                </td>
              </tr>
            ) : (
              matches.map(match => (
                <tr key={match.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {match.home_team?.name || 'Unknown'} vs {match.away_team?.name || 'Unknown'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatMatchDate(match.match_date)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {match.location || 'TBD'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(match.status)}`}>
                      {match.status.charAt(0).toUpperCase() + match.status.slice(1).replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {match.home_score} - {match.away_score}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => openScoreModal(match)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      Update Score
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      
      {/* Score Entry Modal */}
      {isScoreModalOpen && selectedMatch && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-3xl">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">
                Update Score: {selectedMatch.home_team?.name} vs {selectedMatch.away_team?.name}
              </h2>
              <button onClick={closeScoreModal} className="text-gray-500 hover:text-gray-700">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
            
            {/* Match Info */}
            <div className="bg-gray-50 p-4 rounded-md mb-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-gray-500">Date & Time</p>
                  <p className="text-sm font-medium">{formatMatchDate(selectedMatch.match_date)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Location</p>
                  <p className="text-sm font-medium">{selectedMatch.location || 'TBD'}</p>
                </div>
              </div>
            </div>
            
            {/* Score Form */}
            <form onSubmit={handleScoreSubmit} className="mb-6">
              <div className="flex items-center justify-center space-x-8">
                <div className="text-center">
                  <h3 className="text-lg font-medium mb-2">{selectedMatch.home_team?.name}</h3>
                  <input
                    type="number"
                    name="home_score"
                    value={scoreFormData.home_score}
                    onChange={handleScoreChange}
                    min="0"
                    className="w-20 h-20 text-4xl font-bold text-center border-2 border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                
                <div className="text-2xl font-bold">vs</div>
                
                <div className="text-center">
                  <h3 className="text-lg font-medium mb-2">{selectedMatch.away_team?.name}</h3>
                  <input
                    type="number"
                    name="away_score"
                    value={scoreFormData.away_score}
                    onChange={handleScoreChange}
                    min="0"
                    className="w-20 h-20 text-4xl font-bold text-center border-2 border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
              
              <div className="mt-6 flex justify-center">
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  Update Score
                </button>
              </div>
            </form>
            
            {/* Match Events */}
            <div className="border-t pt-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">Match Events</h3>
                <button
                  onClick={openEventModal}
                  className="px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
                >
                  Add Event
                </button>
              </div>
              
              {events.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No events recorded for this match.</p>
              ) : (
                <div className="overflow-y-auto max-h-64">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Time
                        </th>
                        <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Event
                        </th>
                        <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Player
                        </th>
                        <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Team
                        </th>
                        <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Description
                        </th>
                        <th scope="col" className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {events.map(event => (
                        <tr key={event.id}>
                          <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                            {event.event_time}'
                          </td>
                          <td className="px-4 py-2 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getEventTypeBadgeClass(event.event_type)}`}>
                              {event.event_type.charAt(0).toUpperCase() + event.event_type.slice(1).replace('_', ' ')}
                            </span>
                          </td>
                          <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                            {event.player?.first_name} {event.player?.last_name} {event.player?.jersey_number ? `(#${event.player.jersey_number})` : ''}
                          </td>
                          <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                            {event.team?.name || 'Unknown'}
                          </td>
                          <td className="px-4 py-2 text-sm text-gray-500 max-w-xs truncate">
                            {event.description || '-'}
                          </td>
                          <td className="px-4 py-2 whitespace-nowrap text-right text-sm font-medium">
                            <button
                              onClick={() => handleDeleteEvent(event.id)}
                              className="text-red-600 hover:text-red-900"
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      {/* Event Modal */}
      {isEventModalOpen && selectedMatch && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">
                Add Match Event
              </h2>
              <button onClick={closeEventModal} className="text-gray-500 hover:text-gray-700">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
            
            <form onSubmit={handleEventSubmit}>
              <div className="mb-4">
                <label htmlFor="event_type" className="block text-sm font-medium text-gray-700">
                  Event Type
                </label>
                <select
                  id="event_type"
                  name="event_type"
                  value={eventFormData.event_type}
                  onChange={handleEventFormChange}
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="goal">Goal</option>
                  <option value="yellow_card">Yellow Card</option>
                  <option value="red_card">Red Card</option>
                  <option value="substitution">Substitution</option>
                  <option value="injury">Injury</option>
                  <option value="penalty">Penalty</option>
                </select>
              </div>
              
              <div className="mb-4">
                <label htmlFor="team_id" className="block text-sm font-medium text-gray-700">
                  Team
                </label>
                <select
                  id="team_id"
                  name="team_id"
                  value={eventFormData.team_id}
                  onChange={handleEventFormChange}
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select team</option>
                  <option value={selectedMatch.home_team_id}>{selectedMatch.home_team?.name}</option>
                  <option value={selectedMatch.away_team_id}>{selectedMatch.away_team?.name}</option>
                </select>
              </div>
              
              <div className="mb-4">
                <label htmlFor="player_id" className="block text-sm font-medium text-gray-700">
                  Player
                </label>
                <select
                  id="player_id"
                  name="player_id"
                  value={eventFormData.player_id}
                  onChange={handleEventFormChange}
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select player</option>
                  {eventFormData.team_id === selectedMatch.home_team_id && 
                    players.home.map(player => (
                      <option key={player.id} value={player.id}>
                        {player.first_name} {player.last_name} {player.jersey_number ? `(#${player.jersey_number})` : ''}
                      </option>
                    ))
                  }
                  {eventFormData.team_id === selectedMatch.away_team_id && 
                    players.away.map(player => (
                      <option key={player.id} value={player.id}>
                        {player.first_name} {player.last_name} {player.jersey_number ? `(#${player.jersey_number})` : ''}
                      </option>
                    ))
                  }
                </select>
              </div>
              
              <div className="mb-4">
                <label htmlFor="event_time" className="block text-sm font-medium text-gray-700">
                  Event Time (minute)
                </label>
                <input
                  type="number"
                  id="event_time"
                  name="event_time"
                  value={eventFormData.event_time}
                  onChange={handleEventFormChange}
                  required
                  min="1"
                  max="120"
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                  Description (optional)
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={eventFormData.description}
                  onChange={handleEventFormChange}
                  rows="3"
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Add any additional details about the event..."
                ></textarea>
              </div>
              
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={closeEventModal}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  Add Event
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ScoreEntry;