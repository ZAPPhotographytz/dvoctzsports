import { supabase } from './supabase';

/**
 * Authenticate a user with email and password
 * @param {string} email - User email
 * @param {string} password - User password
 * @returns {Promise<{user, error}>} - User object or error
 */
export const signIn = async (email, password) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });
  
  return { user: data?.user, session: data?.session, error };
};

/**
 * Sign out the current user
 * @returns {Promise<{error}>} - Error, if any
 */
export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};

/**
 * Get the current authenticated user
 * @returns {Promise<{user, error}>} - Current user or error
 */
export const getCurrentUser = async () => {
  const { data, error } = await supabase.auth.getUser();
  return { user: data?.user, error };
};

/**
 * Get user profile including role
 * @param {string} userId - User ID to get profile for
 * @returns {Promise<{profile, error}>} - User profile or error
 */
export const getUserProfile = async (userId) => {
  const { data, error } = await supabase
    .from('app_b67db54826_user_profiles')
    .select('*')
    .eq('user_id', userId)
    .single();
    
  return { profile: data, error };
};

/**
 * Check if the current user has admin role
 * @returns {Promise<boolean>} - True if user is admin
 */
export const isAdmin = async () => {
  const { user } = await getCurrentUser();
  if (!user) return false;
  
  const { profile } = await getUserProfile(user.id);
  return profile?.role === 'admin';
};

/**
 * Check if the current user has team manager role
 * @returns {Promise<boolean>} - True if user is team manager
 */
export const isTeamManager = async () => {
  const { user } = await getCurrentUser();
  if (!user) return false;
  
  const { profile } = await getUserProfile(user.id);
  return profile?.role === 'team_manager';
};

/**
 * Check if the current user has referee role
 * @returns {Promise<boolean>} - True if user is referee
 */
export const isReferee = async () => {
  const { user } = await getCurrentUser();
  if (!user) return false;
  
  const { profile } = await getUserProfile(user.id);
  return profile?.role === 'referee';
};