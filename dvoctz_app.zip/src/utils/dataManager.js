import { supabase } from './supabase';

/**
 * Teams related operations
 */
export const teamsManager = {
  // Get all teams
  getAll: async () => {
    const { data, error } = await supabase
      .from('app_b67db54826_teams')
      .select('*')
      .order('name');
    return { teams: data, error };
  },
  
  // Get a specific team
  getById: async (id) => {
    const { data, error } = await supabase
      .from('app_b67db54826_teams')
      .select('*')
      .eq('id', id)
      .single();
    return { team: data, error };
  },
  
  // Create a new team
  create: async (team) => {
    const { data, error } = await supabase
      .from('app_b67db54826_teams')
      .insert(team)
      .select()
      .single();
    return { team: data, error };
  },
  
  // Update a team
  update: async (id, updates) => {
    const { data, error } = await supabase
      .from('app_b67db54826_teams')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    return { team: data, error };
  },
  
  // Delete a team
  delete: async (id) => {
    const { error } = await supabase
      .from('app_b67db54826_teams')
      .delete()
      .eq('id', id);
    return { error };
  }
};

/**
 * Players related operations
 */
export const playersManager = {
  // Get all players
  getAll: async () => {
    const { data, error } = await supabase
      .from('app_b67db54826_players')
      .select(`
        *,
        team:team_id(id, name)
      `)
      .order('last_name');
    return { players: data, error };
  },
  
  // Get players by team
  getByTeam: async (teamId) => {
    const { data, error } = await supabase
      .from('app_b67db54826_players')
      .select('*')
      .eq('team_id', teamId)
      .order('jersey_number');
    return { players: data, error };
  },
  
  // Get a specific player
  getById: async (id) => {
    const { data, error } = await supabase
      .from('app_b67db54826_players')
      .select(`
        *,
        team:team_id(id, name)
      `)
      .eq('id', id)
      .single();
    return { player: data, error };
  },
  
  // Create a new player
  create: async (player) => {
    const { data, error } = await supabase
      .from('app_b67db54826_players')
      .insert(player)
      .select()
      .single();
    return { player: data, error };
  },
  
  // Update a player
  update: async (id, updates) => {
    const { data, error } = await supabase
      .from('app_b67db54826_players')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    return { player: data, error };
  },
  
  // Delete a player
  delete: async (id) => {
    const { error } = await supabase
      .from('app_b67db54826_players')
      .delete()
      .eq('id', id);
    return { error };
  }
};

/**
 * Matches related operations
 */
export const matchesManager = {
  // Get all matches
  getAll: async () => {
    const { data, error } = await supabase
      .from('app_b67db54826_matches')
      .select(`
        *,
        home_team:home_team_id(id, name),
        away_team:away_team_id(id, name),
        referee:referee_id(id, email)
      `)
      .order('match_date');
    return { matches: data, error };
  },
  
  // Get upcoming matches
  getUpcoming: async () => {
    const { data, error } = await supabase
      .from('app_b67db54826_matches')
      .select(`
        *,
        home_team:home_team_id(id, name),
        away_team:away_team_id(id, name),
        referee:referee_id(id, email)
      `)
      .gte('match_date', new Date().toISOString())
      .order('match_date');
    return { matches: data, error };
  },
  
  // Get matches for a team
  getByTeam: async (teamId) => {
    const { data, error } = await supabase
      .from('app_b67db54826_matches')
      .select(`
        *,
        home_team:home_team_id(id, name),
        away_team:away_team_id(id, name),
        referee:referee_id(id, email)
      `)
      .or(`home_team_id.eq.${teamId},away_team_id.eq.${teamId}`)
      .order('match_date');
    return { matches: data, error };
  },
  
  // Get matches for a referee
  getByReferee: async (refereeId) => {
    const { data, error } = await supabase
      .from('app_b67db54826_matches')
      .select(`
        *,
        home_team:home_team_id(id, name),
        away_team:away_team_id(id, name),
        referee:referee_id(id, email)
      `)
      .eq('referee_id', refereeId)
      .order('match_date');
    return { matches: data, error };
  },
  
  // Get a specific match
  getById: async (id) => {
    const { data, error } = await supabase
      .from('app_b67db54826_matches')
      .select(`
        *,
        home_team:home_team_id(id, name),
        away_team:away_team_id(id, name),
        referee:referee_id(id, email)
      `)
      .eq('id', id)
      .single();
    return { match: data, error };
  },
  
  // Create a new match
  create: async (match) => {
    const { data, error } = await supabase
      .from('app_b67db54826_matches')
      .insert(match)
      .select()
      .single();
    return { match: data, error };
  },
  
  // Update a match
  update: async (id, updates) => {
    const { data, error } = await supabase
      .from('app_b67db54826_matches')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    return { match: data, error };
  },
  
  // Delete a match
  delete: async (id) => {
    const { error } = await supabase
      .from('app_b67db54826_matches')
      .delete()
      .eq('id', id);
    return { error };
  },
  
  // Update match score
  updateScore: async (id, homeScore, awayScore) => {
    const { data, error } = await supabase
      .from('app_b67db54826_matches')
      .update({
        home_score: homeScore,
        away_score: awayScore,
        status: 'completed',
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();
    return { match: data, error };
  }
};

/**
 * Match events related operations
 */
export const eventsManager = {
  // Get events for a match
  getByMatch: async (matchId) => {
    const { data, error } = await supabase
      .from('app_b67db54826_match_events')
      .select(`
        *,
        player:player_id(id, first_name, last_name, jersey_number),
        team:team_id(id, name)
      `)
      .eq('match_id', matchId)
      .order('event_time');
    return { events: data, error };
  },
  
  // Create a new match event
  create: async (event) => {
    const { data, error } = await supabase
      .from('app_b67db54826_match_events')
      .insert(event)
      .select()
      .single();
    return { event: data, error };
  },
  
  // Update a match event
  update: async (id, updates) => {
    const { data, error } = await supabase
      .from('app_b67db54826_match_events')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    return { event: data, error };
  },
  
  // Delete a match event
  delete: async (id) => {
    const { error } = await supabase
      .from('app_b67db54826_match_events')
      .delete()
      .eq('id', id);
    return { error };
  }
};

/**
 * League related operations
 */
export const leagueManager = {
  // Get league settings
  getSettings: async () => {
    const { data, error } = await supabase
      .from('app_b67db54826_league_settings')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();
    return { settings: data, error };
  },
  
  // Update league settings
  updateSettings: async (id, updates) => {
    const { data, error } = await supabase
      .from('app_b67db54826_league_settings')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    return { settings: data, error };
  },
  
  // Get league standings
  getStandings: async () => {
    const { data, error } = await supabase
      .from('app_b67db54826_standings')
      .select('*');
    return { standings: data, error };
  }
};

/**
 * User profiles related operations
 */
export const profilesManager = {
  // Get all profiles
  getAll: async () => {
    const { data, error } = await supabase
      .from('app_b67db54826_user_profiles')
      .select('*');
    return { profiles: data, error };
  },
  
  // Get a specific profile
  getById: async (userId) => {
    const { data, error } = await supabase
      .from('app_b67db54826_user_profiles')
      .select('*')
      .eq('user_id', userId)
      .single();
    return { profile: data, error };
  },
  
  // Create a new profile
  create: async (profile) => {
    const { data, error } = await supabase
      .from('app_b67db54826_user_profiles')
      .insert(profile)
      .select()
      .single();
    return { profile: data, error };
  },
  
  // Update a profile
  update: async (userId, updates) => {
    const { data, error } = await supabase
      .from('app_b67db54826_user_profiles')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single();
    return { profile: data, error };
  },
  
  // Get users by role
  getByRole: async (role) => {
    const { data, error } = await supabase
      .from('app_b67db54826_user_profiles')
      .select('*')
      .eq('role', role);
    return { profiles: data, error };
  }
};