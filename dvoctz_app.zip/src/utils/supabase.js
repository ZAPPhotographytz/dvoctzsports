import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://sieezcmdrahujtwkjejs.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNpZWV6Y21kcmFodWp0d2tqZWpzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcxNzQ0ODYsImV4cCI6MjA3Mjc1MDQ4Nn0._dMjD_aqC0Dj8oGYPmewFaDRidG7r0s4ZloN2gJae64';

export const supabase = createClient(supabaseUrl, supabaseKey);