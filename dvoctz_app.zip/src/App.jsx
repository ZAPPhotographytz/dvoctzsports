import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { supabase } from './utils/supabase';
import { getCurrentUser, getUserProfile } from './utils/auth';

// Components
import Login from './components/Auth/Login';
import AdminDashboard from './components/Dashboard/AdminDashboard';
import TeamManagement from './components/Teams/TeamManagement';
import PlayerManagement from './components/Players/PlayerManagement';
import MatchManagement from './components/Matches/MatchManagement';
import ScoreEntry from './components/Referees/ScoreEntry';
import LeagueTables from './components/League/LeagueTables';

function App() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userProfile, setUserProfile] = useState(null);
  
  useEffect(() => {
    // Check for existing session
    const checkSession = async () => {
      setLoading(true);
      
      try {
        // Get the current session
        const { data } = await supabase.auth.getSession();
        setSession(data.session);
        
        // If there's a session, get the user profile
        if (data.session) {
          const { profile } = await getUserProfile(data.session.user.id);
          setUserProfile(profile);
        }
      } catch (error) {
        console.error('Error checking session:', error);
      } finally {
        setLoading(false);
      }
    };
    
    checkSession();
    
    // Set up auth state change listener
    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (event, newSession) => {
        setSession(newSession);
        
        if (newSession) {
          const { profile } = await getUserProfile(newSession.user.id);
          setUserProfile(profile);
        } else {
          setUserProfile(null);
        }
      }
    );
    
    // Clean up subscription on unmount
    return () => {
      if (authListener && authListener.subscription) {
        authListener.subscription.unsubscribe();
      }
    };
  }, []);

  const handleLogin = (user, session) => {
    setSession(session);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setUserProfile(null);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  // If no session, show login page
  if (!session) {
    return <Login onLogin={handleLogin} />;
  }

  // User is logged in, show app with navigation
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        {/* Navigation */}
        <nav className="bg-blue-600 text-white shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <span className="text-xl font-bold">Sports League</span>
                </div>
                <div className="hidden md:block">
                  <div className="ml-10 flex items-baseline space-x-4">
                    <Link to="/" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-blue-700">
                      Dashboard
                    </Link>
                    <Link to="/teams" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-blue-700">
                      Teams
                    </Link>
                    <Link to="/players" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-blue-700">
                      Players
                    </Link>
                    <Link to="/matches" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-blue-700">
                      Matches
                    </Link>
                    {userProfile?.role === 'referee' && (
                      <Link to="/score-entry" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-blue-700">
                        Score Entry
                      </Link>
                    )}
                    <Link to="/standings" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-blue-700">
                      Standings
                    </Link>
                  </div>
                </div>
              </div>
              <div className="flex items-center">
                <span className="mr-4 text-sm">
                  {session?.user?.email} ({userProfile?.role || 'user'})
                </span>
                <button
                  onClick={handleLogout}
                  className="bg-blue-700 px-3 py-1 rounded-md text-sm font-medium hover:bg-blue-800"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          <Routes>
            <Route path="/" element={<AdminDashboard />} />
            <Route path="/teams" element={<TeamManagement />} />
            <Route path="/players" element={<PlayerManagement />} />
            <Route path="/matches" element={<MatchManagement />} />
            <Route 
              path="/score-entry" 
              element={
                userProfile?.role === 'referee' ? (
                  <ScoreEntry />
                ) : (
                  <Navigate to="/" replace />
                )
              } 
            />
            <Route path="/standings" element={<LeagueTables />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;