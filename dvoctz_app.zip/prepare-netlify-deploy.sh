#!/bin/bash
# DVOCTZ Sports League Management App - Netlify Deployment Preparation Script

# Stop on errors
set -e

echo "===== Preparing DVOCTZ Sports League App for Netlify Deployment ====="

# Clean previous builds and dependencies
echo "Cleaning previous builds and dependencies..."
rm -rf dist
rm -rf node_modules

# Install fresh dependencies
echo "Installing dependencies..."
npm install

# Build the application
echo "Building the application..."
npx vite build

# Verify build output
if [ -d "dist" ]; then
  echo "✅ Build successful! dist directory created."
  echo "dist directory contents:"
  ls -la dist/
else
  echo "❌ Build failed! dist directory not created."
  exit 1
fi

echo "===== Deployment preparation complete! ====="
echo "You can now upload this directory to Netlify or deploy via GitHub."
echo "Ensure you include netlify.toml in your repository."
