# DVOCTZ Sports League Management App Deployment Guide

## Proper Directory Structure for Netlify
To ensure successful deployment, your repository should have this structure:

dvoctzsports/
├── dist/              # Generated build folder (will be created during build)
├── public/            # Static assets (if any)
├── src/               # Source code
├── index.html         # HTML entry point
├── package.json       # Dependencies and scripts
├── netlify.toml       # Netlify configuration
└── vite.config.js     # Vite configuration

## Deployment Steps

### Method 1: Deploy from GitHub
1. Push your code to a GitHub repository
2. Sign in to Netlify and connect your GitHub repository
3. Configure build settings:
   - Build command: npm install && npx vite build
   - Publish directory: dist
4. Click "Deploy site"

### Method 2: Manual Upload
1. Run these commands locally:
   ```
   npm install
   npm run build
   ```
2. Verify the dist folder is created with all assets
3. Upload your project folder (with the dist directory) to Netlify
