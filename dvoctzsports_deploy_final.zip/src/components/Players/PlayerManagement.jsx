import React, { useState, useEffect } from 'react';
import { exportToCSV } from '../../utils/dataManager';

const PlayerManagement = () => {
  const [players, setPlayers] = useState([]);
  const [teams, setTeams] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTeam, setFilterTeam] = useState('');
  const [filterDivision, setFilterDivision] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState(null);
  const [newPlayer, setNewPlayer] = useState({
    name: '',
    team: '',
    position: '',
    division: 1
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const playersData = JSON.parse(localStorage.getItem('players') || '[]');
    const teamsData = JSON.parse(localStorage.getItem('teams') || '[]');
    setPlayers(playersData);
    setTeams(teamsData);
  };

  const handleAddPlayer = (e) => {
    e.preventDefault();
    const playersData = JSON.parse(localStorage.getItem('players') || '[]');
    const newId = Math.max(...playersData.map(p => p.id), 0) + 1;
    const playerToAdd = { ...newPlayer, id: newId };
    
    const updatedPlayers = [...playersData, playerToAdd];
    localStorage.setItem('players', JSON.stringify(updatedPlayers));
    
    setPlayers(updatedPlayers);
    setNewPlayer({ name: '', team: '', position: '', division: 1 });
    setShowAddForm(false);
  };

  const handleEditPlayer = (player) => {
    setEditingPlayer(player);
    setNewPlayer(player);
    setShowAddForm(true);
  };

  const handleUpdatePlayer = (e) => {
    e.preventDefault();
    const playersData = JSON.parse(localStorage.getItem('players') || '[]');
    const updatedPlayers = playersData.map(p => 
      p.id === editingPlayer.id ? { ...newPlayer } : p
    );
    
    localStorage.setItem('players', JSON.stringify(updatedPlayers));
    setPlayers(updatedPlayers);
    setEditingPlayer(null);
    setNewPlayer({ name: '', team: '', position: '', division: 1 });
    setShowAddForm(false);
  };

  const handleDeletePlayer = (playerId) => {
    if (window.confirm('Are you sure you want to delete this player?')) {
      const playersData = JSON.parse(localStorage.getItem('players') || '[]');
      const updatedPlayers = playersData.filter(p => p.id !== playerId);
      localStorage.setItem('players', JSON.stringify(updatedPlayers));
      setPlayers(updatedPlayers);
    }
  };

  const handleCSVUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          // Simulate CSV parsing - in real app, use proper CSV parser
          const csvData = event.target.result;
          const lines = csvData.split('\n');
          const headers = lines[0].split(',');
          
          const newPlayers = [];
          for (let i = 1; i < lines.length; i++) {
            if (lines[i].trim()) {
              const values = lines[i].split(',');
              const player = {
                id: Math.max(...players.map(p => p.id), 0) + newPlayers.length + 1,
                name: values[0]?.trim(),
                team: values[1]?.trim(),
                position: values[2]?.trim(),
                division: parseInt(values[3]?.trim()) || 1
              };
              newPlayers.push(player);
            }
          }
          
          const allPlayers = [...players, ...newPlayers];
          localStorage.setItem('players', JSON.stringify(allPlayers));
          setPlayers(allPlayers);
          alert(`Successfully imported ${newPlayers.length} players`);
        } catch (error) {
          alert('Error parsing CSV file');
        }
      };
      reader.readAsText(file);
    }
  };

  const filteredPlayers = players.filter(player => {
    const matchesSearch = player.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         player.team.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTeam = !filterTeam || player.team === filterTeam;
    const matchesDivision = !filterDivision || player.division.toString() === filterDivision;
    
    return matchesSearch && matchesTeam && matchesDivision;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Player Management</h2>
        <div className="flex space-x-4">
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium"
          >
            Add Player
          </button>
          <button
            onClick={() => exportToCSV(players, 'players.csv')}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium"
          >
            Export CSV
          </button>
        </div>
      </div>

      {/* CSV Upload */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Upload Players CSV</h3>
        <div className="flex items-center space-x-4">
          <input
            type="file"
            accept=".csv"
            onChange={handleCSVUpload}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
          />
          <span className="text-sm text-gray-500">CSV format: Name, Team, Position, Division</span>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white shadow rounded-lg p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Search</label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search players or teams..."
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Filter by Team</label>
            <select
              value={filterTeam}
              onChange={(e) => setFilterTeam(e.target.value)}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            >
              <option value="">All Teams</option>
              {teams.map(team => (
                <option key={team.id} value={team.name}>{team.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Filter by Division</label>
            <select
              value={filterDivision}
              onChange={(e) => setFilterDivision(e.target.value)}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            >
              <option value="">All Divisions</option>
              <option value="1">Division 1</option>
              <option value="2">Division 2</option>
            </select>
          </div>
        </div>
      </div>

      {/* Players Table */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Team</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Position</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Division</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredPlayers.map((player) => (
              <tr key={player.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{player.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{player.team}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{player.position}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Division {player.division}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                  <button
                    onClick={() => handleEditPlayer(player)}
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeletePlayer(player.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 className="text-lg font-bold text-gray-900 mb-4">
              {editingPlayer ? 'Edit Player' : 'Add New Player'}
            </h3>
            <form onSubmit={editingPlayer ? handleUpdatePlayer : handleAddPlayer}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Name</label>
                  <input
                    type="text"
                    required
                    value={newPlayer.name}
                    onChange={(e) => setNewPlayer({...newPlayer, name: e.target.value})}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Team</label>
                  <select
                    required
                    value={newPlayer.team}
                    onChange={(e) => setNewPlayer({...newPlayer, team: e.target.value})}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  >
                    <option value="">Select Team</option>
                    {teams.map(team => (
                      <option key={team.id} value={team.name}>{team.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Position</label>
                  <select
                    required
                    value={newPlayer.position}
                    onChange={(e) => setNewPlayer({...newPlayer, position: e.target.value})}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  >
                    <option value="">Select Position</option>
                    <option value="Goalkeeper">Goalkeeper</option>
                    <option value="Defender">Defender</option>
                    <option value="Midfielder">Midfielder</option>
                    <option value="Forward">Forward</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Division</label>
                  <select
                    required
                    value={newPlayer.division}
                    onChange={(e) => setNewPlayer({...newPlayer, division: parseInt(e.target.value)})}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  >
                    <option value={1}>Division 1</option>
                    <option value={2}>Division 2</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddForm(false);
                    setEditingPlayer(null);
                    setNewPlayer({ name: '', team: '', position: '', division: 1 });
                  }}
                  className="bg-gray-300 hover:bg-gray-400 text-black px-4 py-2 rounded-md text-sm font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium"
                >
                  {editingPlayer ? 'Update' : 'Add'} Player
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlayerManagement;