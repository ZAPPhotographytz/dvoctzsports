import { supabase } from '../config/supabase';

export const signUp = async (username, email, password, role = 'user') => {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username,
          role
        }
      }
    });

    if (error) throw error;

    // Insert user data into app_users table
    const { error: insertError } = await supabase
      .from('app_users')
      .insert([
        {
          username,
          email,
          password_hash: 'supabase_managed', // Supabase manages auth
          role
        }
      ]);

    if (insertError) throw insertError;

    return { success: true, data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const signIn = async (email, password) => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) throw error;

    // Get user profile from app_users table
    const { data: profile, error: profileError } = await supabase
      .from('app_users')
      .select('*')
      .eq('email', email)
      .single();

    if (profileError) throw profileError;

    return { 
      success: true, 
      user: {
        id: data.user.id,
        username: profile.username,
        email: profile.email,
        role: profile.role
      }
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const signOut = async () => {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const getCurrentUser = async () => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) return null;

    const { data: profile, error } = await supabase
      .from('app_users')
      .select('*')
      .eq('email', user.email)
      .single();

    if (error) throw error;

    return {
      id: user.id,
      username: profile.username,
      email: profile.email,
      role: profile.role
    };
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
};

export const updateProfile = async (userId, updates) => {
  try {
    const { error } = await supabase
      .from('app_users')
      .update(updates)
      .eq('id', userId);

    if (error) throw error;
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};