-- DVOCTZ Sports League Management Database Schema
-- This file contains all the SQL commands to set up your database

BEGIN;

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create teams table
CREATE TABLE IF NOT EXISTS teams (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    division INTEGER NOT NULL CHECK (division IN (1, 2)),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create players table
CREATE TABLE IF NOT EXISTS players (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    position VARCHAR(100) NOT NULL,
    team_id UUID REFERENCES teams(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create matches table
CREATE TABLE IF NOT EXISTS matches (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    home_team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    away_team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    home_score INTEGER DEFAULT 0,
    away_score INTEGER DEFAULT 0,
    date TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(50) DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'in_progress', 'completed', 'cancelled')),
    division INTEGER NOT NULL CHECK (division IN (1, 2)),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT different_teams CHECK (home_team_id != away_team_id)
);

-- Create league_table table
CREATE TABLE IF NOT EXISTS league_table (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    division INTEGER NOT NULL CHECK (division IN (1, 2)),
    points INTEGER DEFAULT 0,
    wins INTEGER DEFAULT 0,
    draws INTEGER DEFAULT 0,
    losses INTEGER DEFAULT 0,
    goals_for INTEGER DEFAULT 0,
    goals_against INTEGER DEFAULT 0,
    goal_difference INTEGER DEFAULT 0,
    played INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(team_id)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_teams_division ON teams(division);
CREATE INDEX IF NOT EXISTS idx_players_team_id ON players(team_id);
CREATE INDEX IF NOT EXISTS idx_matches_home_team ON matches(home_team_id);
CREATE INDEX IF NOT EXISTS idx_matches_away_team ON matches(away_team_id);
CREATE INDEX IF NOT EXISTS idx_matches_date ON matches(date);
CREATE INDEX IF NOT EXISTS idx_matches_division ON matches(division);
CREATE INDEX IF NOT EXISTS idx_league_table_division ON league_table(division);
CREATE INDEX IF NOT EXISTS idx_league_table_points ON league_table(points DESC);

-- Enable Row Level Security (RLS)
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE league_table ENABLE ROW LEVEL SECURITY;

-- Create RLS policies (allow all operations for now - you can restrict later)
CREATE POLICY "allow_all_teams" ON teams FOR ALL USING (true);
CREATE POLICY "allow_all_players" ON players FOR ALL USING (true);
CREATE POLICY "allow_all_matches" ON matches FOR ALL USING (true);
CREATE POLICY "allow_all_league_table" ON league_table FOR ALL USING (true);

-- Insert sample data
INSERT INTO teams (name, division) VALUES 
    ('Manchester Lions', 1),
    ('Chelsea Eagles', 1),
    ('Arsenal Tigers', 1),
    ('Liverpool Wolves', 1),
    ('Brighton Sharks', 2),
    ('Crystal Falcons', 2),
    ('Tottenham Hawks', 2),
    ('Newcastle Bears', 2)
ON CONFLICT (name) DO NOTHING;

-- Insert league table entries for sample teams
INSERT INTO league_table (team_id, division, points, wins, draws, losses, goals_for, goals_against, goal_difference, played)
SELECT 
    t.id,
    t.division,
    0, 0, 0, 0, 0, 0, 0, 0
FROM teams t
ON CONFLICT (team_id) DO NOTHING;

-- Insert sample players
INSERT INTO players (name, position, team_id) VALUES 
    ('John Smith', 'Forward', (SELECT id FROM teams WHERE name = 'Manchester Lions' LIMIT 1)),
    ('Mike Johnson', 'Midfielder', (SELECT id FROM teams WHERE name = 'Manchester Lions' LIMIT 1)),
    ('David Wilson', 'Defender', (SELECT id FROM teams WHERE name = 'Chelsea Eagles' LIMIT 1)),
    ('Chris Brown', 'Goalkeeper', (SELECT id FROM teams WHERE name = 'Chelsea Eagles' LIMIT 1)),
    ('Alex Davis', 'Forward', (SELECT id FROM teams WHERE name = 'Arsenal Tigers' LIMIT 1)),
    ('Tom Miller', 'Midfielder', (SELECT id FROM teams WHERE name = 'Liverpool Wolves' LIMIT 1))
ON CONFLICT DO NOTHING;

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_teams_updated_at BEFORE UPDATE ON teams FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_players_updated_at BEFORE UPDATE ON players FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_matches_updated_at BEFORE UPDATE ON matches FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_league_table_updated_at BEFORE UPDATE ON league_table FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

COMMIT;