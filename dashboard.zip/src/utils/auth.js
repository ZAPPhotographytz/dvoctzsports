// Authentication utilities
const users = [
  { 
    id: 1, 
    username: 'admin', 
    password: 'admin123', 
    email: 'admin@dvoctz.com',
    role: 'admin' 
  },
  { 
    id: 2, 
    username: 'referee1', 
    password: 'ref123', 
    email: 'referee1@dvoctz.com',
    role: 'referee' 
  },
  { 
    id: 3, 
    username: 'user1', 
    password: 'user123', 
    email: 'user1@dvoctz.com',
    role: 'user' 
  }
];

// Auth roles constant
export const AUTH_ROLES = {
  ADMIN: 'admin',
  REFEREE: 'referee',
  USER: 'user'
};

// Initialize users in localStorage if not exists
const initializeUsers = () => {
  const storedUsers = localStorage.getItem('users');
  if (!storedUsers) {
    localStorage.setItem('users', JSON.stringify(users));
  }
};

// Initialize users on module load
initializeUsers();

export const login = (username, password) => {
  const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
  const user = storedUsers.find(u => u.username === username && u.password === password);
  
  if (user) {
    const userSession = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role
    };
    localStorage.setItem('currentUser', JSON.stringify(userSession));
    return userSession;
  }
  return null;
};

export const logout = () => {
  localStorage.removeItem('currentUser');
};

export const getCurrentUser = () => {
  const user = localStorage.getItem('currentUser');
  return user ? JSON.parse(user) : null;
};

export const isAuthenticated = () => {
  return getCurrentUser() !== null;
};

export const updateUserProfile = (updateData) => {
  try {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      return { success: false, message: 'User not authenticated' };
    }

    const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = storedUsers.findIndex(u => u.id === currentUser.id);
    
    if (userIndex === -1) {
      return { success: false, message: 'User not found' };
    }

    const user = storedUsers[userIndex];

    // If changing password, verify current password
    if (updateData.newPassword) {
      if (!updateData.currentPassword) {
        return { success: false, message: 'Current password is required' };
      }
      
      if (user.password !== updateData.currentPassword) {
        return { success: false, message: 'Current password is incorrect' };
      }
      
      // Update password
      user.password = updateData.newPassword;
    }

    // Check if username is already taken by another user
    if (updateData.username !== user.username) {
      const existingUser = storedUsers.find(u => u.username === updateData.username && u.id !== currentUser.id);
      if (existingUser) {
        return { success: false, message: 'Username is already taken' };
      }
    }

    // Check if email is already taken by another user
    if (updateData.email !== user.email) {
      const existingUser = storedUsers.find(u => u.email === updateData.email && u.id !== currentUser.id);
      if (existingUser) {
        return { success: false, message: 'Email is already taken' };
      }
    }

    // Update user data
    user.username = updateData.username;
    user.email = updateData.email;

    // Save updated users array
    localStorage.setItem('users', JSON.stringify(storedUsers));

    // Update current user session
    const updatedSession = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role
    };
    localStorage.setItem('currentUser', JSON.stringify(updatedSession));

    return { success: true, message: 'Profile updated successfully' };
  } catch (error) {
    return { success: false, message: 'An error occurred while updating profile' };
  }
};