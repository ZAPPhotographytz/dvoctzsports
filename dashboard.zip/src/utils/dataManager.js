// Data management utilities
export const initializeData = () => {
  // Initialize teams
  const teams = JSON.parse(localStorage.getItem('teams') || '[]');
  if (teams.length === 0) {
    const defaultTeams = [
      { id: 1, name: 'Arsenal FC', division: 1 },
      { id: 2, name: 'Chelsea FC', division: 1 },
      { id: 3, name: 'Manchester United', division: 1 },
      { id: 4, name: 'Liverpool FC', division: 1 },
      { id: 5, name: 'Brighton FC', division: 2 },
      { id: 6, name: 'Crystal Palace', division: 2 },
      { id: 7, name: 'Fulham FC', division: 2 },
      { id: 8, name: 'Brentford FC', division: 2 }
    ];
    localStorage.setItem('teams', JSON.stringify(defaultTeams));
  }

  // Initialize players
  const players = JSON.parse(localStorage.getItem('players') || '[]');
  if (players.length === 0) {
    const defaultPlayers = [
      { id: 1, name: 'John Smith', team: 'Arsenal FC', position: 'Forward', division: 1 },
      { id: 2, name: 'Mike Johnson', team: 'Arsenal FC', position: 'Midfielder', division: 1 },
      { id: 3, name: 'David Wilson', team: 'Chelsea FC', position: 'Defender', division: 1 },
      { id: 4, name: 'Chris Brown', team: 'Chelsea FC', position: 'Goalkeeper', division: 1 },
      { id: 5, name: 'Alex Davis', team: 'Brighton FC', position: 'Forward', division: 2 },
      { id: 6, name: 'Sam Miller', team: 'Brighton FC', position: 'Midfielder', division: 2 }
    ];
    localStorage.setItem('players', JSON.stringify(defaultPlayers));
  }

  // Initialize matches
  const matches = JSON.parse(localStorage.getItem('matches') || '[]');
  if (matches.length === 0) {
    const defaultMatches = [
      {
        id: 1,
        date: '2024-01-15',
        time: '15:00',
        venue: 'Emirates Stadium',
        homeTeam: 'Arsenal FC',
        awayTeam: 'Chelsea FC',
        homeScore: null,
        awayScore: null,
        division: 1,
        status: 'scheduled'
      },
      {
        id: 2,
        date: '2024-01-16',
        time: '17:30',
        venue: 'Old Trafford',
        homeTeam: 'Manchester United',
        awayTeam: 'Liverpool FC',
        homeScore: 2,
        awayScore: 1,
        division: 1,
        status: 'completed'
      }
    ];
    localStorage.setItem('matches', JSON.stringify(defaultMatches));
  }

  // Initialize league tables
  initializeLeagueTables();
};

export const initializeLeagueTables = () => {
  const teams = JSON.parse(localStorage.getItem('teams') || '[]');
  const leagueTable = JSON.parse(localStorage.getItem('leagueTable') || '[]');
  
  if (leagueTable.length === 0) {
    const defaultTable = teams.map(team => ({
      teamId: team.id,
      teamName: team.name,
      division: team.division,
      points: 0,
      wins: 0,
      draws: 0,
      losses: 0,
      goalsFor: 0,
      goalsAgainst: 0,
      goalDifference: 0,
      played: 0
    }));
    localStorage.setItem('leagueTable', JSON.stringify(defaultTable));
  }
};

export const updateLeagueTable = (homeTeam, awayTeam, homeScore, awayScore) => {
  const leagueTable = JSON.parse(localStorage.getItem('leagueTable') || '[]');
  
  const homeTeamData = leagueTable.find(t => t.teamName === homeTeam);
  const awayTeamData = leagueTable.find(t => t.teamName === awayTeam);
  
  if (!homeTeamData || !awayTeamData) return;
  
  // Update goals
  homeTeamData.goalsFor += homeScore;
  homeTeamData.goalsAgainst += awayScore;
  awayTeamData.goalsFor += awayScore;
  awayTeamData.goalsAgainst += homeScore;
  
  // Update goal difference
  homeTeamData.goalDifference = homeTeamData.goalsFor - homeTeamData.goalsAgainst;
  awayTeamData.goalDifference = awayTeamData.goalsFor - awayTeamData.goalsAgainst;
  
  // Update matches played
  homeTeamData.played += 1;
  awayTeamData.played += 1;
  
  // Update wins, draws, losses, and points
  if (homeScore > awayScore) {
    homeTeamData.wins += 1;
    homeTeamData.points += 3;
    awayTeamData.losses += 1;
  } else if (homeScore < awayScore) {
    awayTeamData.wins += 1;
    awayTeamData.points += 3;
    homeTeamData.losses += 1;
  } else {
    homeTeamData.draws += 1;
    homeTeamData.points += 1;
    awayTeamData.draws += 1;
    awayTeamData.points += 1;
  }
  
  localStorage.setItem('leagueTable', JSON.stringify(leagueTable));
};

// Export functions for getting data
export const getAllTeams = () => {
  return JSON.parse(localStorage.getItem('teams') || '[]');
};

export const getAllPlayers = () => {
  return JSON.parse(localStorage.getItem('players') || '[]');
};

export const getAllMatches = () => {
  return JSON.parse(localStorage.getItem('matches') || '[]');
};

export const getDivisionTable = (division) => {
  const leagueTable = JSON.parse(localStorage.getItem('leagueTable') || '[]');
  return leagueTable
    .filter(team => team.division === division)
    .sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      if (b.goalDifference !== a.goalDifference) return b.goalDifference - a.goalDifference;
      return b.goalsFor - a.goalsFor;
    });
};

export const getLeagueTable = () => {
  return JSON.parse(localStorage.getItem('leagueTable') || '[]');
};

export const exportToCSV = (data, filename) => {
  const csvContent = convertToCSV(data);
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

const convertToCSV = (data) => {
  if (!data.length) return '';
  
  const headers = Object.keys(data[0]);
  const csvHeaders = headers.join(',');
  const csvRows = data.map(row => 
    headers.map(header => {
      const value = row[header];
      return typeof value === 'string' && value.includes(',') ? `"${value}"` : value;
    }).join(',')
  );
  
  return [csvHeaders, ...csvRows].join('\n');
};