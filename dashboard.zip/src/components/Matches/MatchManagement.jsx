import React, { useState, useEffect } from 'react';
import { exportToCSV } from '../../utils/dataManager';

const MatchManagement = () => {
  const [matches, setMatches] = useState([]);
  const [teams, setTeams] = useState([]);
  const [filterDivision, setFilterDivision] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newMatch, setNewMatch] = useState({
    date: '',
    time: '',
    venue: '',
    homeTeam: '',
    awayTeam: '',
    division: 1
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const matchesData = JSON.parse(localStorage.getItem('matches') || '[]');
    const teamsData = JSON.parse(localStorage.getItem('teams') || '[]');
    setMatches(matchesData);
    setTeams(teamsData);
  };

  const handleAddMatch = (e) => {
    e.preventDefault();
    const matchesData = JSON.parse(localStorage.getItem('matches') || '[]');
    const newId = Math.max(...matchesData.map(m => m.id), 0) + 1;
    
    const matchToAdd = {
      ...newMatch,
      id: newId,
      homeScore: null,
      awayScore: null,
      status: 'scheduled'
    };
    
    const updatedMatches = [...matchesData, matchToAdd];
    localStorage.setItem('matches', JSON.stringify(updatedMatches));
    
    setMatches(updatedMatches);
    setNewMatch({
      date: '',
      time: '',
      venue: '',
      homeTeam: '',
      awayTeam: '',
      division: 1
    });
    setShowAddForm(false);
  };

  const handleDeleteMatch = (matchId) => {
    if (window.confirm('Are you sure you want to delete this match?')) {
      const matchesData = JSON.parse(localStorage.getItem('matches') || '[]');
      const updatedMatches = matchesData.filter(m => m.id !== matchId);
      localStorage.setItem('matches', JSON.stringify(updatedMatches));
      setMatches(updatedMatches);
    }
  };

  const handleCSVUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const csvData = event.target.result;
          const lines = csvData.split('\n');
          
          const newMatches = [];
          for (let i = 1; i < lines.length; i++) {
            if (lines[i].trim()) {
              const values = lines[i].split(',');
              const match = {
                id: Math.max(...matches.map(m => m.id), 0) + newMatches.length + 1,
                date: values[0]?.trim(),
                time: values[1]?.trim(),
                venue: values[2]?.trim(),
                homeTeam: values[3]?.trim(),
                awayTeam: values[4]?.trim(),
                division: parseInt(values[5]?.trim()) || 1,
                homeScore: null,
                awayScore: null,
                status: 'scheduled'
              };
              newMatches.push(match);
            }
          }
          
          const allMatches = [...matches, ...newMatches];
          localStorage.setItem('matches', JSON.stringify(allMatches));
          setMatches(allMatches);
          alert(`Successfully imported ${newMatches.length} matches`);
        } catch (error) {
          alert('Error parsing CSV file');
        }
      };
      reader.readAsText(file);
    }
  };

  const filteredMatches = matches.filter(match => {
    const matchesDivision = !filterDivision || match.division.toString() === filterDivision;
    const matchesStatus = !filterStatus || match.status === filterStatus;
    return matchesDivision && matchesStatus;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'scheduled':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Match Management</h2>
        <div className="flex space-x-4">
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium"
          >
            Add Match
          </button>
          <button
            onClick={() => exportToCSV(matches, 'matches.csv')}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium"
          >
            Export CSV
          </button>
        </div>
      </div>

      {/* CSV Upload */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Upload Fixtures CSV</h3>
        <div className="flex items-center space-x-4">
          <input
            type="file"
            accept=".csv"
            onChange={handleCSVUpload}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
          />
          <span className="text-sm text-gray-500">CSV format: Date, Time, Venue, Home Team, Away Team, Division</span>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white shadow rounded-lg p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Filter by Division</label>
            <select
              value={filterDivision}
              onChange={(e) => setFilterDivision(e.target.value)}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            >
              <option value="">All Divisions</option>
              <option value="1">Division 1</option>
              <option value="2">Division 2</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Filter by Status</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            >
              <option value="">All Status</option>
              <option value="scheduled">Scheduled</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>
      </div>

      {/* Matches Table */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Match</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Venue</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Division</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Score</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredMatches.map((match) => (
              <tr key={match.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  <div>{match.date}</div>
                  <div className="text-gray-500">{match.time}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  <div className="font-medium">{match.homeTeam} vs {match.awayTeam}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{match.venue}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Division {match.division}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {match.homeScore !== null && match.awayScore !== null 
                    ? `${match.homeScore} - ${match.awayScore}`
                    : '-'
                  }
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(match.status)}`}>
                    {match.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => handleDeleteMatch(match.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Match Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Add New Match</h3>
            <form onSubmit={handleAddMatch}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Date</label>
                  <input
                    type="date"
                    required
                    value={newMatch.date}
                    onChange={(e) => setNewMatch({...newMatch, date: e.target.value})}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Time</label>
                  <input
                    type="time"
                    required
                    value={newMatch.time}
                    onChange={(e) => setNewMatch({...newMatch, time: e.target.value})}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Venue</label>
                  <input
                    type="text"
                    required
                    value={newMatch.venue}
                    onChange={(e) => setNewMatch({...newMatch, venue: e.target.value})}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Home Team</label>
                  <select
                    required
                    value={newMatch.homeTeam}
                    onChange={(e) => setNewMatch({...newMatch, homeTeam: e.target.value})}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  >
                    <option value="">Select Home Team</option>
                    {teams.map(team => (
                      <option key={team.id} value={team.name}>{team.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Away Team</label>
                  <select
                    required
                    value={newMatch.awayTeam}
                    onChange={(e) => setNewMatch({...newMatch, awayTeam: e.target.value})}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  >
                    <option value="">Select Away Team</option>
                    {teams.filter(team => team.name !== newMatch.homeTeam).map(team => (
                      <option key={team.id} value={team.name}>{team.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Division</label>
                  <select
                    required
                    value={newMatch.division}
                    onChange={(e) => setNewMatch({...newMatch, division: parseInt(e.target.value)})}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  >
                    <option value={1}>Division 1</option>
                    <option value={2}>Division 2</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddForm(false);
                    setNewMatch({
                      date: '',
                      time: '',
                      venue: '',
                      homeTeam: '',
                      awayTeam: '',
                      division: 1
                    });
                  }}
                  className="bg-gray-300 hover:bg-gray-400 text-black px-4 py-2 rounded-md text-sm font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium"
                >
                  Add Match
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default MatchManagement;