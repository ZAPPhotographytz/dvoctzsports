# DVOCTZ Sports League Management - Production Deployment Guide

## 🚀 Complete Setup Instructions

Follow these simple steps to deploy your DVOCTZ app to **www.dvoctz.com** with a fully functional database.

---

## Step 1: Create Supabase Account & Project

### 1.1 Sign Up for Supabase (FREE)
1. Go to [https://supabase.com](https://supabase.com)
2. Click **"Start your project"**
3. Sign up with your email or GitHub account
4. Verify your email if required

### 1.2 Create New Project
1. Click **"New Project"**
2. Choose your organization (or create one)
3. Fill in project details:
   - **Name**: `DVOCTZ Sports League`
   - **Database Password**: Create a strong password (save this!)
   - **Region**: Choose closest to your location
4. Click **"Create new project"**
5. Wait 2-3 minutes for setup to complete

---

## Step 2: Set Up Database

### 2.1 Get Project Details
1. In your Supabase dashboard, go to **Settings** → **API**
2. Copy these values (you'll need them later):
   - **Project URL** (looks like: `https://abcdefgh.supabase.co`)
   - **Project Reference ID** (looks like: `abcdefgh`)
   - **anon public key** (long string starting with `eyJ...`)

### 2.2 Create Database Tables
1. In Supabase dashboard, go to **SQL Editor**
2. Click **"New Query"**
3. Copy the entire content from `supabase-setup.sql` file (I created this for you)
4. Paste it into the SQL editor
5. Click **"Run"** button
6. You should see "Success. No rows returned" message

---

## Step 3: Deploy to Vercel

### 3.1 Create Vercel Account (FREE)
1. Go to [https://vercel.com](https://vercel.com)
2. Click **"Sign Up"**
3. Sign up with GitHub (recommended)

### 3.2 Deploy Your App
1. In Vercel dashboard, click **"New Project"**
2. Import from Git Repository:
   - If you have the code on GitHub: Select your repository
   - If not: Upload the `/workspace/dashboard` folder as a ZIP file
3. Configure project:
   - **Project Name**: `dvoctz-sports-league`
   - **Framework Preset**: Vite
   - **Root Directory**: `./` (leave as default)

### 3.3 Add Environment Variables
1. In the deployment settings, click **"Environment Variables"**
2. Add these variables:
   ```
   VITE_SUPABASE_URL = [Your Project URL from Step 2.1]
   VITE_SUPABASE_ANON_KEY = [Your anon public key from Step 2.1]
   ```
3. Click **"Deploy"**

---

## Step 4: Connect Your Domain

### 4.1 Add Custom Domain
1. After deployment, go to your project dashboard in Vercel
2. Click **"Domains"** tab
3. Click **"Add"**
4. Enter: `www.dvoctz.com`
5. Vercel will show you DNS records to add

### 4.2 Update DNS Settings
1. Go to your domain registrar (where you bought dvoctz.com)
2. Find DNS settings/management
3. Add the DNS records that Vercel provided:
   - **Type**: CNAME
   - **Name**: www
   - **Value**: [Vercel's provided value]
4. Save changes (may take 24-48 hours to propagate)

---

## Step 5: Test Your Deployment

### 5.1 Access Your App
1. Visit your Vercel deployment URL (provided after deployment)
2. Test login with:
   - **Admin**: username: `admin`, password: `admin123`
   - **User**: username: `user`, password: `user123`
   - **Referee**: username: `referee`, password: `ref123`

### 5.2 Test Features
1. Login as admin
2. Go to **Teams** section
3. Try adding a new team
4. Check if data persists after page refresh
5. Test other features (players, matches, etc.)

---

## 🎉 You're Done!

Your DVOCTZ Sports League Management app is now live at:
- **Temporary URL**: [Your Vercel URL]
- **Custom Domain**: www.dvoctz.com (once DNS propagates)

## 📞 Need Help?

If you encounter any issues:
1. Check the Vercel deployment logs
2. Verify your environment variables are correct
3. Ensure the Supabase SQL setup completed successfully
4. Contact me for technical support

## 🔒 Security Notes

- Change default passwords after deployment
- Consider enabling additional Supabase security features
- Monitor your usage to stay within free tier limits

---

**Congratulations! Your sports league management system is now live and ready to use! 🏆⚽**