# Sports Team & League Management App - MVP Implementation

## Core Files to Create/Modify:

1. **index.html** - Update title for Sports Management App
2. **src/App.jsx** - Main app with routing and authentication context
3. **src/components/Auth/Login.jsx** - Login component for different user roles
4. **src/components/Dashboard/AdminDashboard.jsx** - Admin dashboard with navigation
5. **src/components/Players/PlayerManagement.jsx** - Player CRUD operations and CSV upload
6. **src/components/Teams/TeamManagement.jsx** - Team pages and player listings
7. **src/components/Matches/MatchManagement.jsx** - Match scheduling and CSV upload
8. **src/components/Referees/ScoreEntry.jsx** - Referee score entry interface
9. **src/components/League/LeagueTables.jsx** - Division 1 & 2 league tables
10. **src/data/mockData.js** - Replace with sports data structure
11. **src/utils/auth.js** - Authentication utilities
12. **src/utils/dataManager.js** - Data management utilities

## Data Structure (localStorage):
- users: [{id, username, password, role}]
- players: [{id, name, team, position, division}]
- teams: [{id, name, division, players}]
- matches: [{id, date, time, venue, homeTeam, awayTeam, homeScore, awayScore, division, status}]
- leagueTable: [{teamId, division, points, wins, draws, losses, goalsFor, goalsAgainst, goalDifference}]

## MVP Features:
1. Simple role-based authentication (Admin/Referee/User)
2. Player management with CSV upload simulation
3. Team pages with player listings
4. Match scheduling with CSV upload simulation
5. Referee score entry
6. Auto-updating league tables for 2 divisions
7. Basic search and filter functionality
8. CSV export capability

## Implementation Priority:
- Focus on core functionality over complex features
- Use localStorage for data persistence
- Simulate file uploads with JSON data
- Keep UI clean and functional