import { createClient } from '@supabase/supabase-js'

// These will be environment variables in production
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database initialization SQL
export const initializeDatabase = async () => {
  try {
    // Create users table
    await supabase.rpc('exec_sql', {
      query: `
        -- Create users table
        CREATE TABLE IF NOT EXISTS app_users (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          username VARCHAR(50) UNIQUE NOT NULL,
          email VARCHAR(100) UNIQUE NOT NULL,
          password_hash VARCHAR(255) NOT NULL,
          role VARCHAR(20) DEFAULT 'user' CHECK (role IN ('admin', 'referee', 'user')),
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Create teams table
        CREATE TABLE IF NOT EXISTS teams (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          name VARCHAR(100) UNIQUE NOT NULL,
          division INTEGER NOT NULL CHECK (division IN (1, 2)),
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Create players table
        CREATE TABLE IF NOT EXISTS players (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          name VARCHAR(100) NOT NULL,
          team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
          position VARCHAR(50) NOT NULL,
          division INTEGER NOT NULL CHECK (division IN (1, 2)),
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Create matches table
        CREATE TABLE IF NOT EXISTS matches (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          date DATE NOT NULL,
          time TIME NOT NULL,
          venue VARCHAR(200) NOT NULL,
          home_team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
          away_team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
          home_score INTEGER,
          away_score INTEGER,
          division INTEGER NOT NULL CHECK (division IN (1, 2)),
          status VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled')),
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Create league_table table
        CREATE TABLE IF NOT EXISTS league_table (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          team_id UUID REFERENCES teams(id) ON DELETE CASCADE UNIQUE,
          division INTEGER NOT NULL CHECK (division IN (1, 2)),
          points INTEGER DEFAULT 0,
          wins INTEGER DEFAULT 0,
          draws INTEGER DEFAULT 0,
          losses INTEGER DEFAULT 0,
          goals_for INTEGER DEFAULT 0,
          goals_against INTEGER DEFAULT 0,
          goal_difference INTEGER DEFAULT 0,
          played INTEGER DEFAULT 0,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Insert default admin user (password: admin123)
        INSERT INTO app_users (username, email, password_hash, role) 
        VALUES ('admin', 'admin@dvoctz.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin')
        ON CONFLICT (username) DO NOTHING;

        -- Insert sample teams
        INSERT INTO teams (name, division) VALUES 
        ('Arsenal FC', 1),
        ('Chelsea FC', 1),
        ('Manchester United', 1),
        ('Liverpool FC', 1),
        ('Brighton FC', 2),
        ('Crystal Palace', 2),
        ('Fulham FC', 2),
        ('Brentford FC', 2)
        ON CONFLICT (name) DO NOTHING;
      `
    });
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Error initializing database:', error);
  }
};