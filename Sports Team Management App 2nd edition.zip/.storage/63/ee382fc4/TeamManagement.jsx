import React, { useState, useEffect } from 'react';

const TeamManagement = ({ userRole }) => {
  const [teams, setTeams] = useState([]);
  const [players, setPlayers] = useState([]);
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [filterDivision, setFilterDivision] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTeam, setNewTeam] = useState({
    name: '',
    division: 1
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const teamsData = JSON.parse(localStorage.getItem('teams') || '[]');
    const playersData = JSON.parse(localStorage.getItem('players') || '[]');
    setTeams(teamsData);
    setPlayers(playersData);
  };

  const handleAddTeam = (e) => {
    e.preventDefault();
    if (!newTeam.name.trim()) return;

    const existingTeams = JSON.parse(localStorage.getItem('teams') || '[]');
    
    // Check if team name already exists
    if (existingTeams.some(team => team.name.toLowerCase() === newTeam.name.toLowerCase())) {
      alert('Team name already exists!');
      return;
    }

    const newTeamData = {
      id: Date.now(),
      name: newTeam.name.trim(),
      division: parseInt(newTeam.division)
    };

    const updatedTeams = [...existingTeams, newTeamData];
    localStorage.setItem('teams', JSON.stringify(updatedTeams));

    // Create league table entry for new team
    const leagueTable = JSON.parse(localStorage.getItem('leagueTable') || '[]');
    const newLeagueEntry = {
      teamName: newTeamData.name,
      division: newTeamData.division,
      points: 0,
      wins: 0,
      draws: 0,
      losses: 0,
      goalsFor: 0,
      goalsAgainst: 0,
      goalDifference: 0,
      played: 0
    };
    leagueTable.push(newLeagueEntry);
    localStorage.setItem('leagueTable', JSON.stringify(leagueTable));

    loadData();
    setNewTeam({ name: '', division: 1 });
    setShowAddForm(false);
    alert('Team added successfully!');
  };

  const handleDeleteTeam = (teamId, teamName) => {
    if (!window.confirm(`Are you sure you want to delete ${teamName}? This will also remove all players from this team and cannot be undone.`)) {
      return;
    }

    // Remove team
    const existingTeams = JSON.parse(localStorage.getItem('teams') || '[]');
    const updatedTeams = existingTeams.filter(team => team.id !== teamId);
    localStorage.setItem('teams', JSON.stringify(updatedTeams));

    // Remove from league table
    const leagueTable = JSON.parse(localStorage.getItem('leagueTable') || '[]');
    const updatedLeagueTable = leagueTable.filter(entry => entry.teamName !== teamName);
    localStorage.setItem('leagueTable', JSON.stringify(updatedLeagueTable));

    // Update players (remove team association)
    const existingPlayers = JSON.parse(localStorage.getItem('players') || '[]');
    const updatedPlayers = existingPlayers.map(player => 
      player.team === teamName ? { ...player, team: 'No Team' } : player
    );
    localStorage.setItem('players', JSON.stringify(updatedPlayers));

    // Remove matches involving this team
    const existingMatches = JSON.parse(localStorage.getItem('matches') || '[]');
    const updatedMatches = existingMatches.filter(match => 
      match.homeTeam !== teamName && match.awayTeam !== teamName
    );
    localStorage.setItem('matches', JSON.stringify(updatedMatches));

    loadData();
    setSelectedTeam(null);
    alert('Team deleted successfully!');
  };

  const getTeamPlayers = (teamName) => {
    return players.filter(player => player.team === teamName);
  };

  const getTeamStats = (teamName) => {
    const teamPlayers = getTeamPlayers(teamName);
    const leagueTable = JSON.parse(localStorage.getItem('leagueTable') || '[]');
    const teamStats = leagueTable.find(t => t.teamName === teamName);
    
    return {
      playerCount: teamPlayers.length,
      points: teamStats?.points || 0,
      wins: teamStats?.wins || 0,
      draws: teamStats?.draws || 0,
      losses: teamStats?.losses || 0,
      goalsFor: teamStats?.goalsFor || 0,
      goalsAgainst: teamStats?.goalsAgainst || 0
    };
  };

  const filteredTeams = teams.filter(team => {
    return !filterDivision || team.division.toString() === filterDivision;
  });

  const TeamCard = ({ team }) => {
    const stats = getTeamStats(team.name);
    const teamPlayers = getTeamPlayers(team.name);

    return (
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{team.name}</h3>
            <p className="text-sm text-gray-500">Division {team.division}</p>
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => setSelectedTeam(team)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded text-sm"
            >
              View Details
            </button>
            {userRole === 'admin' && (
              <button
                onClick={() => handleDeleteTeam(team.id, team.name)}
                className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm"
                disabled={loading}
              >
                Delete
              </button>
            )}
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-500">Players:</span>
            <span className="ml-2 font-medium">{stats.playerCount}</span>
          </div>
          <div>
            <span className="text-gray-500">Points:</span>
            <span className="ml-2 font-medium">{stats.points}</span>
          </div>
          <div>
            <span className="text-gray-500">Wins:</span>
            <span className="ml-2 font-medium">{stats.wins}</span>
          </div>
          <div>
            <span className="text-gray-500">Goals:</span>
            <span className="ml-2 font-medium">{stats.goalsFor}-{stats.goalsAgainst}</span>
          </div>
        </div>

        <div className="mt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Recent Players:</h4>
          <div className="space-y-1">
            {teamPlayers.slice(0, 3).map(player => (
              <div key={player.id} className="text-sm text-gray-600">
                {player.name} - {player.position}
              </div>
            ))}
            {teamPlayers.length > 3 && (
              <div className="text-sm text-gray-500">
                +{teamPlayers.length - 3} more players
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Team Management</h2>
        <div className="flex items-center space-x-4">
          <select
            value={filterDivision}
            onChange={(e) => setFilterDivision(e.target.value)}
            className="border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm px-3 py-2"
          >
            <option value="">All Divisions</option>
            <option value="1">Division 1</option>
            <option value="2">Division 2</option>
          </select>
          {userRole === 'admin' && (
            <button
              onClick={() => setShowAddForm(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center"
              disabled={loading}
            >
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Add New Team
            </button>
          )}
        </div>
      </div>

      {/* Add Team Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-900">Add New Team</h3>
              <button
                onClick={() => setShowAddForm(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <form onSubmit={handleAddTeam} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Team Name
                </label>
                <input
                  type="text"
                  value={newTeam.name}
                  onChange={(e) => setNewTeam({ ...newTeam, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter team name"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Division
                </label>
                <select
                  value={newTeam.division}
                  onChange={(e) => setNewTeam({ ...newTeam, division: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value={1}>Division 1</option>
                  <option value={2}>Division 2</option>
                </select>
              </div>
              
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-md disabled:opacity-50"
                >
                  {loading ? 'Adding...' : 'Add Team'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Teams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full text-center py-8">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            <p className="mt-2 text-gray-600">Loading teams...</p>
          </div>
        ) : filteredTeams.length > 0 ? (
          filteredTeams.map((team) => (
            <TeamCard key={team.id} team={team} />
          ))
        ) : (
          <div className="col-span-full text-center py-8">
            <div className="bg-gray-50 rounded-lg p-8">
              <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
              <h3 className="mt-2 text-sm font-medium text-gray-900">No teams found</h3>
              <p className="mt-1 text-sm text-gray-500">
                {userRole === 'admin' ? 'Get started by adding your first team.' : 'No teams available to display.'}
              </p>
              {userRole === 'admin' && (
                <div className="mt-6">
                  <button
                    onClick={() => setShowAddForm(true)}
                    className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                  >
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                    Add New Team
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Team Detail Modal */}
      {selectedTeam && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-4/5 max-w-4xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900">{selectedTeam.name}</h3>
              <button
                onClick={() => setSelectedTeam(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Team Stats */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Team Statistics</h4>
                <div className="space-y-3">
                  {(() => {
                    const stats = getTeamStats(selectedTeam.name);
                    return (
                      <>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Division:</span>
                          <span className="font-medium">Division {selectedTeam.division}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Players:</span>
                          <span className="font-medium">{stats.playerCount}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Points:</span>
                          <span className="font-medium">{stats.points}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Wins:</span>
                          <span className="font-medium">{stats.wins}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Draws:</span>
                          <span className="font-medium">{stats.draws}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Losses:</span>
                          <span className="font-medium">{stats.losses}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Goals For:</span>
                          <span className="font-medium">{stats.goalsFor}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Goals Against:</span>
                          <span className="font-medium">{stats.goalsAgainst}</span>
                        </div>
                      </>
                    );
                  })()}
                </div>
              </div>

              {/* Team Players */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Team Roster</h4>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {getTeamPlayers(selectedTeam.name).map(player => (
                    <div key={player.id} className="bg-white border rounded-lg p-3">
                      <div className="flex justify-between items-center">
                        <div>
                          <h5 className="font-medium text-gray-900">{player.name}</h5>
                          <p className="text-sm text-gray-500">{player.position}</p>
                        </div>
                        <div className="text-sm text-gray-400">
                          #{player.id}
                        </div>
                      </div>
                    </div>
                  ))}
                  {getTeamPlayers(selectedTeam.name).length === 0 && (
                    <div className="text-center text-gray-500 py-8">
                      No players registered for this team
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Delete Team Button in Modal */}
            {userRole === 'admin' && (
              <div className="mt-6 pt-4 border-t border-gray-200">
                <button
                  onClick={() => handleDeleteTeam(selectedTeam.id, selectedTeam.name)}
                  className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
                >
                  Delete Team
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamManagement;