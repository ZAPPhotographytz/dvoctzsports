import React, { useState, useEffect } from 'react';
import { getAllTeams, createTeam, deleteTeam } from '../../utils/supabaseData';

const TeamManagement = ({ userRole }) => {
  const [teams, setTeams] = useState([]);
  const [players, setPlayers] = useState([]);
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [filterDivision, setFilterDivision] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTeam, setNewTeam] = useState({
    name: '',
    division: 1
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const teamsData = await getAllTeams();
      const playersData = JSON.parse(localStorage.getItem('players') || '[]');
      setTeams(teamsData);
      setPlayers(playersData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddTeam = async (e) => {
    e.preventDefault();
    if (!newTeam.name.trim()) return;

    setLoading(true);
    try {
      const result = await createTeam({
        name: newTeam.name.trim(),
        division: parseInt(newTeam.division)
      });

      if (result.success) {
        await loadData();
        setNewTeam({ name: '', division: 1 });
        setShowAddForm(false);
        alert('Team added successfully!');
      } else {
        alert('Error adding team: ' + result.error);
      }
    } catch (error) {
      alert('Error adding team: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteTeam = async (teamId, teamName) => {
    if (!window.confirm(`Are you sure you want to delete ${teamName}? This action cannot be undone.`)) {
      return;
    }

    setLoading(true);
    try {
      const result = await deleteTeam(teamId);
      if (result.success) {
        await loadData();
        setSelectedTeam(null);
        alert('Team deleted successfully!');
      } else {
        alert('Error deleting team: ' + result.error);
      }
    } catch (error) {
      alert('Error deleting team: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const getTeamPlayers = (teamName) => {
    return players.filter(player => player.team === teamName);
  };

  const getTeamStats = (teamName) => {
    const teamPlayers = getTeamPlayers(teamName);
    const leagueTable = JSON.parse(localStorage.getItem('leagueTable') || '[]');
    const teamStats = leagueTable.find(t => t.teamName === teamName);
    
    return {
      playerCount: teamPlayers.length,
      points: teamStats?.points || 0,
      wins: teamStats?.wins || 0,
      draws: teamStats?.draws || 0,
      losses: teamStats?.losses || 0,
      goalsFor: teamStats?.goalsFor || 0,
      goalsAgainst: teamStats?.goalsAgainst || 0
    };
  };

  const filteredTeams = teams.filter(team => {
    return !filterDivision || team.division.toString() === filterDivision;
  });

  const TeamCard = ({ team }) => {
    const stats = getTeamStats(team.name);
    const teamPlayers = getTeamPlayers(team.name);

    return (
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{team.name}</h3>
            <p className="text-sm text-gray-500">Division {team.division}</p>
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => setSelectedTeam(team)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded text-sm"
            >
              View Details
            </button>
            {userRole === 'admin' && (
              <button
                onClick={() => handleDeleteTeam(team.id, team.name)}
                className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm"
                disabled={loading}
              >
                Delete
              </button>
            )}
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-500">Players:</span>
            <span className="ml-2 font-medium">{stats.playerCount}</span>
          </div>
          <div>
            <span className="text-gray-500">Points:</span>
            <span className="ml-2 font-medium">{stats.points}</span>
          </div>
          <div>
            <span className="text-gray-500">Wins:</span>
            <span className="ml-2 font-medium">{stats.wins}</span>
          </div>
          <div>
            <span className="text-gray-500">Goals:</span>
            <span className="ml-2 font-medium">{stats.goalsFor}-{stats.goalsAgainst}</span>
          </div>
        </div>

        <div className="mt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Recent Players:</h4>
          <div className="space-y-1">
            {teamPlayers.slice(0, 3).map(player => (
              <div key={player.id} className="text-sm text-gray-600">
                {player.name} - {player.position}
              </div>
            ))}
            {teamPlayers.length > 3 && (
              <div className="text-sm text-gray-500">
                +{teamPlayers.length - 3} more players
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Team Management</h2>
        <div className="flex items-center space-x-4">
          <select
            value={filterDivision}
            onChange={(e) => setFilterDivision(e.target.value)}
            className="border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value="">All Divisions</option>
            <option value="1">Division 1</option>
            <option value="2">Division 2</option>
          </select>
          {userRole === 'admin' && (
            <button
              onClick={() => setShowAddForm(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium"
              disabled={loading}
            >
              Add New Team
            </button>
          )}
        </div>
      </div>

      {/* Add Team Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-900">Add New Team</h3>
              <button
                onClick={() => setShowAddForm(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <form onSubmit={handleAddTeam} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Team Name
                </label>
                <input
                  type="text"
                  value={newTeam.name}
                  onChange={(e) => setNewTeam({ ...newTeam, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter team name"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Division
                </label>
                <select
                  value={newTeam.division}
                  onChange={(e) => setNewTeam({ ...newTeam, division: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value={1}>Division 1</option>
                  <option value={2}>Division 2</option>
                </select>
              </div>
              
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-md disabled:opacity-50"
                >
                  {loading ? 'Adding...' : 'Add Team'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Teams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full text-center py-8">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            <p className="mt-2 text-gray-600">Loading teams...</p>
          </div>
        ) : filteredTeams.length > 0 ? (
          filteredTeams.map((team) => (
            <TeamCard key={team.id} team={team} />
          ))
        ) : (
          <div className="col-span-full text-center py-8">
            <p className="text-gray-500">No teams found. {userRole === 'admin' ? 'Add a new team to get started!' : ''}</p>
          </div>
        )}
      </div>

      {/* Team Detail Modal */}
      {selectedTeam && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-4/5 max-w-4xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900">{selectedTeam.name}</h3>
              <button
                onClick={() => setSelectedTeam(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Team Stats */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Team Statistics</h4>
                <div className="space-y-3">
                  {(() => {
                    const stats = getTeamStats(selectedTeam.name);
                    return (
                      <>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Division:</span>
                          <span className="font-medium">Division {selectedTeam.division}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Players:</span>
                          <span className="font-medium">{stats.playerCount}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Points:</span>
                          <span className="font-medium">{stats.points}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Wins:</span>
                          <span className="font-medium">{stats.wins}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Draws:</span>
                          <span className="font-medium">{stats.draws}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Losses:</span>
                          <span className="font-medium">{stats.losses}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Goals For:</span>
                          <span className="font-medium">{stats.goalsFor}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Goals Against:</span>
                          <span className="font-medium">{stats.goalsAgainst}</span>
                        </div>
                      </>
                    );
                  })()}
                </div>
              </div>

              {/* Team Players */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Team Roster</h4>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {getTeamPlayers(selectedTeam.name).map(player => (
                    <div key={player.id} className="bg-white border rounded-lg p-3">
                      <div className="flex justify-between items-center">
                        <div>
                          <h5 className="font-medium text-gray-900">{player.name}</h5>
                          <p className="text-sm text-gray-500">{player.position}</p>
                        </div>
                        <div className="text-sm text-gray-400">
                          #{player.id}
                        </div>
                      </div>
                    </div>
                  ))}
                  {getTeamPlayers(selectedTeam.name).length === 0 && (
                    <div className="text-center text-gray-500 py-8">
                      No players registered for this team
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamManagement;