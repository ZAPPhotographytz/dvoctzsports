import { supabase } from '../config/supabase';

// Teams
export const getAllTeams = async () => {
  try {
    const { data, error } = await supabase
      .from('teams')
      .select('*')
      .order('name');
    
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching teams:', error);
    return [];
  }
};

export const createTeam = async (team) => {
  try {
    const { data, error } = await supabase
      .from('teams')
      .insert([team])
      .select();
    
    if (error) throw error;
    return { success: true, data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Players
export const getAllPlayers = async () => {
  try {
    const { data, error } = await supabase
      .from('players')
      .select(`
        *,
        teams (
          name
        )
      `)
      .order('name');
    
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching players:', error);
    return [];
  }
};

export const createPlayer = async (player) => {
  try {
    const { data, error } = await supabase
      .from('players')
      .insert([player])
      .select();
    
    if (error) throw error;
    return { success: true, data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Matches
export const getAllMatches = async () => {
  try {
    const { data, error } = await supabase
      .from('matches')
      .select(`
        *,
        home_team:teams!matches_home_team_id_fkey (name),
        away_team:teams!matches_away_team_id_fkey (name)
      `)
      .order('date', { ascending: false });
    
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching matches:', error);
    return [];
  }
};

export const createMatch = async (match) => {
  try {
    const { data, error } = await supabase
      .from('matches')
      .insert([match])
      .select();
    
    if (error) throw error;
    return { success: true, data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const updateMatchScore = async (matchId, homeScore, awayScore) => {
  try {
    const { data, error } = await supabase
      .from('matches')
      .update({
        home_score: homeScore,
        away_score: awayScore,
        status: 'completed'
      })
      .eq('id', matchId)
      .select();
    
    if (error) throw error;
    
    // Update league table
    if (data && data[0]) {
      await updateLeagueTable(data[0]);
    }
    
    return { success: true, data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// League Table
export const getLeagueTable = async (division = null) => {
  try {
    let query = supabase
      .from('league_table')
      .select(`
        *,
        teams (
          name
        )
      `)
      .order('points', { ascending: false })
      .order('goal_difference', { ascending: false })
      .order('goals_for', { ascending: false });
    
    if (division) {
      query = query.eq('division', division);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching league table:', error);
    return [];
  }
};

const updateLeagueTable = async (match) => {
  try {
    // Get current league table entries for both teams
    const { data: homeTeamEntry } = await supabase
      .from('league_table')
      .select('*')
      .eq('team_id', match.home_team_id)
      .single();
    
    const { data: awayTeamEntry } = await supabase
      .from('league_table')
      .select('*')
      .eq('team_id', match.away_team_id)
      .single();
    
    // Calculate updates for home team
    const homeUpdates = calculateTeamUpdates(homeTeamEntry, match.home_score, match.away_score, true);
    const awayUpdates = calculateTeamUpdates(awayTeamEntry, match.away_score, match.home_score, false);
    
    // Update both teams
    await supabase
      .from('league_table')
      .update(homeUpdates)
      .eq('team_id', match.home_team_id);
    
    await supabase
      .from('league_table')
      .update(awayUpdates)
      .eq('team_id', match.away_team_id);
    
  } catch (error) {
    console.error('Error updating league table:', error);
  }
};

const calculateTeamUpdates = (currentEntry, goalsFor, goalsAgainst, isHome) => {
  const newGoalsFor = (currentEntry.goals_for || 0) + goalsFor;
  const newGoalsAgainst = (currentEntry.goals_against || 0) + goalsAgainst;
  const newPlayed = (currentEntry.played || 0) + 1;
  
  let newWins = currentEntry.wins || 0;
  let newDraws = currentEntry.draws || 0;
  let newLosses = currentEntry.losses || 0;
  let newPoints = currentEntry.points || 0;
  
  if (goalsFor > goalsAgainst) {
    newWins += 1;
    newPoints += 3;
  } else if (goalsFor === goalsAgainst) {
    newDraws += 1;
    newPoints += 1;
  } else {
    newLosses += 1;
  }
  
  return {
    goals_for: newGoalsFor,
    goals_against: newGoalsAgainst,
    goal_difference: newGoalsFor - newGoalsAgainst,
    played: newPlayed,
    wins: newWins,
    draws: newDraws,
    losses: newLosses,
    points: newPoints,
    updated_at: new Date().toISOString()
  };
};