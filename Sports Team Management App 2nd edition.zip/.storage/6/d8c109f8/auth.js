// Authentication utilities
export const AUTH_ROLES = {
  ADMIN: 'admin',
  REFEREE: 'referee',
  USER: 'user'
};

export const initializeAuth = () => {
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  if (users.length === 0) {
    // Initialize default users
    const defaultUsers = [
      { id: 1, username: 'admin', password: 'admin123', role: AUTH_ROLES.ADMIN },
      { id: 2, username: 'referee1', password: 'ref123', role: AUTH_ROLES.REFEREE },
      { id: 3, username: 'user1', password: 'user123', role: AUTH_ROLES.USER }
    ];
    localStorage.setItem('users', JSON.stringify(defaultUsers));
  }
};

export const login = (username, password) => {
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  const user = users.find(u => u.username === username && u.password === password);
  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
    return user;
  }
  return null;
};

export const logout = () => {
  localStorage.removeItem('currentUser');
};

export const getCurrentUser = () => {
  return JSON.parse(localStorage.getItem('currentUser') || 'null');
};

export const isAuthenticated = () => {
  return getCurrentUser() !== null;
};

export const hasRole = (role) => {
  const user = getCurrentUser();
  return user && user.role === role;
};