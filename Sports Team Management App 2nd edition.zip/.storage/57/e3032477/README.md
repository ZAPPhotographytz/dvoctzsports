# DVOCTZ Sports League Management System

A comprehensive sports league management application built with React, Tailwind CSS, and Supabase.

## Features

- **User Management**: Admin, Referee, and User roles with authentication
- **Team Management**: Create and manage teams across multiple divisions
- **Player Management**: Add, edit, and organize players by teams
- **Match Scheduling**: Schedule and manage matches with score tracking
- **League Tables**: Automatic league table generation with live standings
- **Profile Management**: Users can update their profile information

## Demo Accounts

- **Admin**: admin@dvoctz.com / admin123
- **Referee**: referee1@dvoctz.com / ref123
- **User**: user1@dvoctz.com / user123

## Deployment Guide

### 1. Database Setup (Supabase)

1. Go to [supabase.com](https://supabase.com) and create a new project
2. Copy your project URL and anon key
3. Create a `.env` file with your Supabase credentials:
   ```
   VITE_SUPABASE_URL=https://your-project-id.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-key-here
   ```

### 2. Deploy to Vercel

1. Push your code to GitHub
2. Connect your GitHub repo to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy automatically

### 3. Custom Domain Setup

1. In Vercel dashboard, go to Settings → Domains
2. Add your custom domain: `www.dvoctz.com`
3. Update your DNS records as instructed by Vercel

## Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Tech Stack

- **Frontend**: React 18, Tailwind CSS
- **Backend**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **Deployment**: Vercel
- **Domain**: www.dvoctz.com

## Project Structure

```
src/
├── components/
│   ├── Auth/           # Login and authentication
│   ├── Dashboard/      # Main dashboard
│   ├── Players/        # Player management
│   ├── Teams/          # Team management
│   ├── Matches/        # Match scheduling
│   ├── Referees/       # Score entry
│   ├── League/         # League tables
│   └── Profile/        # User profiles
├── config/
│   └── supabase.js     # Database configuration
├── utils/
│   ├── auth.js         # Authentication utilities
│   ├── supabaseAuth.js # Supabase auth functions
│   └── supabaseData.js # Database operations
└── App.jsx             # Main application
```

## License

MIT License - Feel free to use this project for your sports league!