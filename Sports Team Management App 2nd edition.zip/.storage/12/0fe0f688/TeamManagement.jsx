import React, { useState, useEffect } from 'react';
import { AUTH_ROLES } from '../../utils/auth';

const TeamManagement = ({ userRole }) => {
  const [teams, setTeams] = useState([]);
  const [players, setPlayers] = useState([]);
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [filterDivision, setFilterDivision] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const teamsData = JSON.parse(localStorage.getItem('teams') || '[]');
    const playersData = JSON.parse(localStorage.getItem('players') || '[]');
    setTeams(teamsData);
    setPlayers(playersData);
  };

  const getTeamPlayers = (teamName) => {
    return players.filter(player => player.team === teamName);
  };

  const getTeamStats = (teamName) => {
    const teamPlayers = getTeamPlayers(teamName);
    const leagueTable = JSON.parse(localStorage.getItem('leagueTable') || '[]');
    const teamStats = leagueTable.find(t => t.teamName === teamName);
    
    return {
      playerCount: teamPlayers.length,
      points: teamStats?.points || 0,
      wins: teamStats?.wins || 0,
      draws: teamStats?.draws || 0,
      losses: teamStats?.losses || 0,
      goalsFor: teamStats?.goalsFor || 0,
      goalsAgainst: teamStats?.goalsAgainst || 0
    };
  };

  const filteredTeams = teams.filter(team => {
    return !filterDivision || team.division.toString() === filterDivision;
  });

  const TeamCard = ({ team }) => {
    const stats = getTeamStats(team.name);
    const teamPlayers = getTeamPlayers(team.name);

    return (
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{team.name}</h3>
            <p className="text-sm text-gray-500">Division {team.division}</p>
          </div>
          <button
            onClick={() => setSelectedTeam(team)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded text-sm"
          >
            View Details
          </button>
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-500">Players:</span>
            <span className="ml-2 font-medium">{stats.playerCount}</span>
          </div>
          <div>
            <span className="text-gray-500">Points:</span>
            <span className="ml-2 font-medium">{stats.points}</span>
          </div>
          <div>
            <span className="text-gray-500">Wins:</span>
            <span className="ml-2 font-medium">{stats.wins}</span>
          </div>
          <div>
            <span className="text-gray-500">Goals:</span>
            <span className="ml-2 font-medium">{stats.goalsFor}-{stats.goalsAgainst}</span>
          </div>
        </div>

        <div className="mt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Recent Players:</h4>
          <div className="space-y-1">
            {teamPlayers.slice(0, 3).map(player => (
              <div key={player.id} className="text-sm text-gray-600">
                {player.name} - {player.position}
              </div>
            ))}
            {teamPlayers.length > 3 && (
              <div className="text-sm text-gray-500">
                +{teamPlayers.length - 3} more players
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Team Management</h2>
        <div className="flex items-center space-x-4">
          <select
            value={filterDivision}
            onChange={(e) => setFilterDivision(e.target.value)}
            className="border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value="">All Divisions</option>
            <option value="1">Division 1</option>
            <option value="2">Division 2</option>
          </select>
        </div>
      </div>

      {/* Teams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTeams.map((team) => (
          <TeamCard key={team.id} team={team} />
        ))}
      </div>

      {/* Team Detail Modal */}
      {selectedTeam && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-4/5 max-w-4xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900">{selectedTeam.name}</h3>
              <button
                onClick={() => setSelectedTeam(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Team Stats */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Team Statistics</h4>
                <div className="space-y-3">
                  {(() => {
                    const stats = getTeamStats(selectedTeam.name);
                    return (
                      <>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Division:</span>
                          <span className="font-medium">Division {selectedTeam.division}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Players:</span>
                          <span className="font-medium">{stats.playerCount}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Points:</span>
                          <span className="font-medium">{stats.points}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Wins:</span>
                          <span className="font-medium">{stats.wins}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Draws:</span>
                          <span className="font-medium">{stats.draws}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Losses:</span>
                          <span className="font-medium">{stats.losses}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Goals For:</span>
                          <span className="font-medium">{stats.goalsFor}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Goals Against:</span>
                          <span className="font-medium">{stats.goalsAgainst}</span>
                        </div>
                      </>
                    );
                  })()}
                </div>
              </div>

              {/* Team Players */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Team Roster</h4>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {getTeamPlayers(selectedTeam.name).map(player => (
                    <div key={player.id} className="bg-white border rounded-lg p-3">
                      <div className="flex justify-between items-center">
                        <div>
                          <h5 className="font-medium text-gray-900">{player.name}</h5>
                          <p className="text-sm text-gray-500">{player.position}</p>
                        </div>
                        <div className="text-sm text-gray-400">
                          #{player.id}
                        </div>
                      </div>
                    </div>
                  ))}
                  {getTeamPlayers(selectedTeam.name).length === 0 && (
                    <div className="text-center text-gray-500 py-8">
                      No players registered for this team
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamManagement;