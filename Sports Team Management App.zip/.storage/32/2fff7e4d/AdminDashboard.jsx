import React, { useState, useEffect } from 'react';
import { getAllTeams, getAllPlayers, getAllMatches, getDivisionTable } from '../../utils/dataManager';
import PlayerManagement from '../Players/PlayerManagement';
import TeamManagement from '../Teams/TeamManagement';
import MatchManagement from '../Matches/MatchManagement';
import ScoreEntry from '../Referees/ScoreEntry';
import LeagueTables from '../League/LeagueTables';

const AdminDashboard = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState({
    totalTeams: 0,
    totalPlayers: 0,
    totalMatches: 0,
    completedMatches: 0
  });

  useEffect(() => {
    const teams = getAllTeams();
    const players = getAllPlayers();
    const matches = getAllMatches();
    
    setStats({
      totalTeams: teams.length,
      totalPlayers: players.length,
      totalMatches: matches.length,
      completedMatches: matches.filter(m => m.status === 'completed').length
    });
  }, [activeTab]);

  const quickActions = [
    { id: 'players', label: 'Manage Players', icon: '👥', color: 'bg-blue-500' },
    { id: 'teams', label: 'Manage Teams', icon: '🏆', color: 'bg-green-500' },
    { id: 'matches', label: 'Schedule Matches', icon: '⚽', color: 'bg-orange-500' },
    { id: 'scores', label: 'Enter Scores', icon: '📊', color: 'bg-purple-500' },
    { id: 'tables', label: 'League Tables', icon: '📋', color: 'bg-red-500' }
  ];

  const handleQuickAction = (actionId) => {
    setActiveTab(actionId);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'players':
        return <PlayerManagement />;
      case 'teams':
        return <TeamManagement />;
      case 'matches':
        return <MatchManagement />;
      case 'scores':
        return <ScoreEntry />;
      case 'tables':
        return <LeagueTables />;
      default:
        return (
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <span className="text-2xl">🏆</span>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Teams</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.totalTeams}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <span className="text-2xl">👥</span>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Players</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.totalPlayers}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-orange-100 rounded-lg">
                    <span className="text-2xl">⚽</span>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Matches</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.totalMatches}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <span className="text-2xl">✅</span>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Completed</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.completedMatches}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {quickActions.map((action) => (
                  <button
                    key={action.id}
                    onClick={() => handleQuickAction(action.id)}
                    className={`${action.color} text-white p-4 rounded-lg hover:opacity-90 transition-opacity`}
                  >
                    <div className="text-2xl mb-2">{action.icon}</div>
                    <div className="text-sm font-medium">{action.label}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Activity</h3>
              <div className="space-y-3">
                <div className="flex items-center text-sm">
                  <span className="w-2 h-2 bg-green-400 rounded-full mr-3"></span>
                  <span className="text-gray-600">System initialized with sample data</span>
                </div>
                <div className="flex items-center text-sm">
                  <span className="w-2 h-2 bg-blue-400 rounded-full mr-3"></span>
                  <span className="text-gray-600">League tables updated</span>
                </div>
                <div className="flex items-center text-sm">
                  <span className="w-2 h-2 bg-orange-400 rounded-full mr-3"></span>
                  <span className="text-gray-600">Ready for match scheduling</span>
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">DVOCTZ Dashboard</h1>
              <p className="text-sm text-gray-600">Welcome back, {user.username} ({user.role})</p>
            </div>
            <button
              onClick={onLogout}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'players', label: 'Players' },
              { id: 'teams', label: 'Teams' },
              { id: 'matches', label: 'Matches' },
              { id: 'scores', label: 'Scores' },
              { id: 'tables', label: 'League Tables' }
            ].filter(tab => {
              if (user.role === 'referee') {
                return ['overview', 'scores', 'tables'].includes(tab.id);
              }
              if (user.role === 'user') {
                return ['overview', 'teams', 'tables'].includes(tab.id);
              }
              return true;
            }).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;