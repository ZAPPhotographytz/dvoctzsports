import React, { useState, useEffect } from 'react';
import { exportToCSV } from '../../utils/dataManager';

const LeagueTables = () => {
  const [leagueTable, setLeagueTable] = useState([]);
  const [selectedDivision, setSelectedDivision] = useState(1);

  useEffect(() => {
    loadLeagueTable();
  }, []);

  const loadLeagueTable = () => {
    const tableData = JSON.parse(localStorage.getItem('leagueTable') || '[]');
    setLeagueTable(tableData);
  };

  const getDivisionTable = (division) => {
    return leagueTable
      .filter(team => team.division === division)
      .sort((a, b) => {
        // Sort by points (descending), then goal difference (descending), then goals for (descending)
        if (b.points !== a.points) return b.points - a.points;
        if (b.goalDifference !== a.goalDifference) return b.goalDifference - a.goalDifference;
        return b.goalsFor - a.goalsFor;
      })
      .map((team, index) => ({ ...team, position: index + 1 }));
  };

  const getPositionColor = (position) => {
    if (position <= 3) return 'text-green-600 font-semibold'; // Top 3
    if (position <= 6) return 'text-blue-600'; // Mid table
    return 'text-gray-600'; // Bottom
  };

  const division1Table = getDivisionTable(1);
  const division2Table = getDivisionTable(2);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">League Tables</h2>
        <div className="flex space-x-4">
          <button
            onClick={() => exportToCSV(getDivisionTable(selectedDivision), `division_${selectedDivision}_table.csv`)}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium"
          >
            Export Table
          </button>
        </div>
      </div>

      {/* Division Tabs */}
      <div className="bg-white shadow rounded-lg">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6">
            <button
              onClick={() => setSelectedDivision(1)}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                selectedDivision === 1
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Division 1
            </button>
            <button
              onClick={() => setSelectedDivision(2)}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                selectedDivision === 2
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Division 2
            </button>
          </nav>
        </div>

        {/* League Table */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pos</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Team</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">P</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">W</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">D</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">L</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">GF</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">GA</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">GD</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Pts</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {(selectedDivision === 1 ? division1Table : division2Table).map((team) => (
                <tr key={team.teamId} className="hover:bg-gray-50">
                  <td className={`px-6 py-4 whitespace-nowrap text-sm ${getPositionColor(team.position)}`}>
                    {team.position}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{team.teamName}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">{team.played}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">{team.wins}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">{team.draws}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">{team.losses}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">{team.goalsFor}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">{team.goalsAgainst}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    <span className={team.goalDifference >= 0 ? 'text-green-600' : 'text-red-600'}>
                      {team.goalDifference > 0 ? '+' : ''}{team.goalDifference}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900 text-center">{team.points}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Table Legend */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
          <div className="text-xs text-gray-500">
            <span className="font-medium">P:</span> Played, 
            <span className="font-medium ml-2">W:</span> Won, 
            <span className="font-medium ml-2">D:</span> Drawn, 
            <span className="font-medium ml-2">L:</span> Lost, 
            <span className="font-medium ml-2">GF:</span> Goals For, 
            <span className="font-medium ml-2">GA:</span> Goals Against, 
            <span className="font-medium ml-2">GD:</span> Goal Difference, 
            <span className="font-medium ml-2">Pts:</span> Points
          </div>
        </div>
      </div>

      {/* Division Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Division 1 Stats</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Teams:</span>
              <span className="font-medium">{division1Table.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Total Goals:</span>
              <span className="font-medium">{division1Table.reduce((sum, team) => sum + team.goalsFor, 0)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Average Goals per Team:</span>
              <span className="font-medium">
                {division1Table.length > 0 
                  ? (division1Table.reduce((sum, team) => sum + team.goalsFor, 0) / division1Table.length).toFixed(1)
                  : '0.0'
                }
              </span>
            </div>
            {division1Table.length > 0 && (
              <>
                <div className="flex justify-between">
                  <span className="text-gray-600">Leader:</span>
                  <span className="font-medium text-green-600">{division1Table[0]?.teamName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Top Scorer:</span>
                  <span className="font-medium">
                    {division1Table.reduce((max, team) => team.goalsFor > max.goalsFor ? team : max, division1Table[0])?.teamName}
                  </span>
                </div>
              </>
            )}
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Division 2 Stats</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Teams:</span>
              <span className="font-medium">{division2Table.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Total Goals:</span>
              <span className="font-medium">{division2Table.reduce((sum, team) => sum + team.goalsFor, 0)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Average Goals per Team:</span>
              <span className="font-medium">
                {division2Table.length > 0 
                  ? (division2Table.reduce((sum, team) => sum + team.goalsFor, 0) / division2Table.length).toFixed(1)
                  : '0.0'
                }
              </span>
            </div>
            {division2Table.length > 0 && (
              <>
                <div className="flex justify-between">
                  <span className="text-gray-600">Leader:</span>
                  <span className="font-medium text-green-600">{division2Table[0]?.teamName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Top Scorer:</span>
                  <span className="font-medium">
                    {division2Table.reduce((max, team) => team.goalsFor > max.goalsFor ? team : max, division2Table[0])?.teamName}
                  </span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeagueTables;